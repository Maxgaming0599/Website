import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Coins, Gift, Ticket } from 'lucide-react';
import { getProducts, getSiteSettings } from '@/db/api';
import type { Product, SiteSettings } from '@/types';
import ProductCard from '@/components/store/ProductCard';
import DailyRewardDialog from '@/components/store/DailyRewardDialog';
import CouponDialog from '@/components/store/CouponDialog';
import InviteRewardsDialog from '@/components/store/InviteRewardsDialog';
import { Link } from 'react-router-dom';

export default function HomePage() {
  const { profile } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [dailyOpen, setDailyOpen] = useState(false);
  const [couponOpen, setCouponOpen] = useState(false);
  const [inviteOpen, setInviteOpen] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [productsData, settingsData] = await Promise.all([
      getProducts(),
      getSiteSettings()
    ]);
    setProducts(productsData.slice(0, 6));
    setSettings(settingsData);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="gradient-bg py-20 px-4">
        <div className="container mx-auto text-center">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 animate-float">
            {settings?.site_name || 'MineMart'}
          </h1>
          <p className="text-xl md:text-2xl text-white/90 mb-8">
            Your Ultimate Minecraft & Discord Store
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Button size="lg" onClick={() => setDailyOpen(true)} className="gap-2">
              <Gift className="w-5 h-5" />
              Daily Reward
            </Button>
            <Button size="lg" variant="outline" onClick={() => setCouponOpen(true)} className="gap-2 bg-white/10 border-white/20 hover:bg-white/20">
              <Ticket className="w-5 h-5" />
              Redeem Coupon
            </Button>
            <Button size="lg" variant="outline" onClick={() => setInviteOpen(true)} className="gap-2 bg-white/10 border-white/20 hover:bg-white/20">
              <Coins className="w-5 h-5" />
              Invite Rewards
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center gradient-text">
            Featured Products
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          <div className="text-center">
            <Button asChild size="lg">
              <Link to="/store">View All Products</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Ranks Section */}
      <section className="py-16 px-4 bg-muted/50">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center gradient-text">
            Premium Ranks
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="border-primary/20 hover:border-primary transition-colors">
              <CardHeader>
                <CardTitle className="text-2xl text-primary">VIP</CardTitle>
                <CardDescription className="text-xl font-bold">₹70</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <p>⚡ Daily 200 Coins</p>
                <p>👑 Discord VIP Role</p>
              </CardContent>
            </Card>
            <Card className="border-secondary/20 hover:border-secondary transition-colors">
              <CardHeader>
                <CardTitle className="text-2xl text-secondary">VIP+</CardTitle>
                <CardDescription className="text-xl font-bold">₹120</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <p>⚡ Daily 299 Coins</p>
                <p>👑 Discord VIP+ Role</p>
              </CardContent>
            </Card>
            <Card className="border-primary/20 hover:border-primary transition-colors">
              <CardHeader>
                <CardTitle className="text-2xl gradient-text">Premium</CardTitle>
                <CardDescription className="text-xl font-bold">₹180</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <p>⚡ Daily 300 Coins</p>
                <p>👑 Discord Premium Role</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center gradient-text">
            Browse Categories
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => window.location.href = '/categories?type=minecraft'}>
              <CardHeader>
                <CardTitle className="text-2xl">🎮 Minecraft</CardTitle>
                <CardDescription>Maps, Plugins, Setups & More</CardDescription>
              </CardHeader>
            </Card>
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => window.location.href = '/categories?type=discord'}>
              <CardHeader>
                <CardTitle className="text-2xl">💬 Discord</CardTitle>
                <CardDescription>Templates, Bots & Setups</CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Dialogs */}
      <DailyRewardDialog open={dailyOpen} onOpenChange={setDailyOpen} />
      <CouponDialog open={couponOpen} onOpenChange={setCouponOpen} />
      <InviteRewardsDialog open={inviteOpen} onOpenChange={setInviteOpen} />
    </div>
  );
}
