import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { getUserPurchasedProducts, downloadProductFile } from '@/db/api';
import type { Product } from '@/types';
import { Download, Package } from 'lucide-react';
import { toast } from 'sonner';

export default function MyPurchasesPage() {
  const { user, profile, loading } = useAuth();
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [downloading, setDownloading] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/login');
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (user) {
      loadPurchases();
    }
  }, [user]);

  const loadPurchases = async () => {
    if (!user) return;
    setLoadingProducts(true);
    const data = await getUserPurchasedProducts(user.id);
    setProducts(data);
    setLoadingProducts(false);
  };

  const handleDownload = async (product: Product) => {
    if (!product.file_url) {
      toast.error('No file available for download');
      return;
    }

    setDownloading(product.id);
    try {
      const blob = await downloadProductFile(product.file_url);
      if (blob) {
        // Create download link
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${product.name}.${product.file_url.split('.').pop()}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        toast.success('Download started');
      } else {
        toast.error('Failed to download file');
      }
    } catch (error) {
      console.error('Download error:', error);
      toast.error('Failed to download file');
    } finally {
      setDownloading(null);
    }
  };

  if (loading || loadingProducts) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold gradient-text mb-2">My Purchases</h1>
          <p className="text-muted-foreground">Download your purchased products</p>
        </div>

        {products.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Package className="w-16 h-16 text-muted-foreground mb-4" />
              <h3 className="text-xl font-semibold mb-2">No purchases yet</h3>
              <p className="text-muted-foreground mb-4">Start shopping to see your purchases here</p>
              <Button onClick={() => navigate('/store')}>Browse Store</Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <Card key={product.id} className="flex flex-col">
                {product.image_url && (
                  <div className="aspect-video w-full overflow-hidden rounded-t-lg">
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <CardHeader>
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="text-xl">{product.name}</CardTitle>
                    {product.file_url && (
                      <Badge variant="secondary" className="gap-1">
                        <Download className="w-3 h-3" />
                        File
                      </Badge>
                    )}
                  </div>
                  {product.description && (
                    <CardDescription>{product.description}</CardDescription>
                  )}
                </CardHeader>
                <CardFooter className="mt-auto">
                  {product.file_url ? (
                    <Button
                      onClick={() => handleDownload(product)}
                      disabled={downloading === product.id}
                      className="w-full gap-2"
                    >
                      <Download className="w-4 h-4" />
                      {downloading === product.id ? 'Downloading...' : 'Download File'}
                    </Button>
                  ) : (
                    <p className="text-sm text-muted-foreground w-full text-center">
                      No downloadable file available
                    </p>
                  )}
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
