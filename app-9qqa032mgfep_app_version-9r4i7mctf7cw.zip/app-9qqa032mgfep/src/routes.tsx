import LoadingPage from './pages/LoadingPage';
import HomePage from './pages/HomePage';
import StorePage from './pages/StorePage';
import CategoriesPage from './pages/CategoriesPage';
import AdminPanelPage from './pages/AdminPanelPage';
import OwnerPanelPage from './pages/OwnerPanelPage';
import PaymentSuccessPage from './pages/PaymentSuccessPage';
import LoginPage from './pages/LoginPage';
import MyPurchasesPage from './pages/MyPurchasesPage';
import NotFound from './pages/NotFound';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Loading',
    path: '/',
    element: <LoadingPage />
  },
  {
    name: 'Home',
    path: '/home',
    element: <HomePage />
  },
  {
    name: 'Store',
    path: '/store',
    element: <StorePage />
  },
  {
    name: 'Categories',
    path: '/categories',
    element: <CategoriesPage />
  },
  {
    name: 'My Purchases',
    path: '/my-purchases',
    element: <MyPurchasesPage />
  },
  {
    name: 'Admin Panel',
    path: '/admin',
    element: <AdminPanelPage />
  },
  {
    name: 'Owner Panel',
    path: '/owner',
    element: <OwnerPanelPage />
  },
  {
    name: 'Payment Success',
    path: '/payment-success',
    element: <PaymentSuccessPage />
  },
  {
    name: 'Login',
    path: '/login',
    element: <LoginPage />
  },
  {
    name: 'Not Found',
    path: '/404',
    element: <NotFound />
  }
];

export default routes;
