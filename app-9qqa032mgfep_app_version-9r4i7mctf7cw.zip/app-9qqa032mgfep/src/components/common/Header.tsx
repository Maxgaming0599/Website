import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu, Coins, Users, LogOut, LogIn, Shield, Crown } from 'lucide-react';
import { toast } from 'sonner';
import { useState } from 'react';

export default function Header() {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    toast.success('Logged out successfully');
    navigate('/login');
  };

  const NavLinks = () => (
    <>
      <Link to="/home" className="hover:text-primary transition-colors" onClick={() => setOpen(false)}>
        Home
      </Link>
      <Link to="/store" className="hover:text-primary transition-colors" onClick={() => setOpen(false)}>
        Store
      </Link>
      <Link to="/categories?type=minecraft" className="hover:text-primary transition-colors" onClick={() => setOpen(false)}>
        Minecraft
      </Link>
      <Link to="/categories?type=discord" className="hover:text-primary transition-colors" onClick={() => setOpen(false)}>
        Discord
      </Link>
      {user && (
        <Link to="/my-purchases" className="hover:text-primary transition-colors" onClick={() => setOpen(false)}>
          My Purchases
        </Link>
      )}
      {profile?.role === 'admin' && (
        <>
          <Link to="/owner" className="hover:text-primary transition-colors flex items-center gap-1" onClick={() => setOpen(false)}>
            <Crown className="w-4 h-4" />
            Owner
          </Link>
          <Link to="/admin" className="hover:text-primary transition-colors flex items-center gap-1" onClick={() => setOpen(false)}>
            <Shield className="w-4 h-4" />
            Admin
          </Link>
        </>
      )}
    </>
  );

  return (
    <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/home" className="text-2xl font-bold gradient-text">
            MineMart
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <NavLinks />
          </nav>

          {/* Right Section */}
          <div className="flex items-center gap-4">
            {user && profile && (
              <div className="flex items-center gap-2 px-3 py-1 bg-primary/10 rounded-full">
                <Coins className="w-4 h-4 text-primary" />
                <span className="font-bold">{profile.coins}</span>
              </div>
            )}
            
            {user && profile && (
              <div className="hidden md:flex items-center gap-2 px-3 py-1 bg-secondary/10 rounded-full">
                <Users className="w-4 h-4 text-secondary" />
                <span className="font-bold">{profile.invite_count}</span>
              </div>
            )}

            {user ? (
              <Button variant="outline" size="sm" onClick={handleSignOut} className="hidden md:flex gap-2">
                <LogOut className="w-4 h-4" />
                Logout
              </Button>
            ) : (
              <Button asChild size="sm" className="hidden md:flex gap-2">
                <Link to="/login">
                  <LogIn className="w-4 h-4" />
                  Login
                </Link>
              </Button>
            )}

            {/* Mobile Menu */}
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="md:hidden">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <div className="flex flex-col gap-6 mt-8">
                  {user && profile && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 px-3 py-2 bg-primary/10 rounded-lg">
                        <Coins className="w-5 h-5 text-primary" />
                        <span className="font-bold">{profile.coins} Coins</span>
                      </div>
                      <div className="flex items-center gap-2 px-3 py-2 bg-secondary/10 rounded-lg">
                        <Users className="w-5 h-5 text-secondary" />
                        <span className="font-bold">{profile.invite_count} Invites</span>
                      </div>
                    </div>
                  )}
                  
                  <nav className="flex flex-col gap-4">
                    <NavLinks />
                  </nav>

                  {user ? (
                    <Button variant="outline" onClick={handleSignOut} className="gap-2">
                      <LogOut className="w-4 h-4" />
                      Logout
                    </Button>
                  ) : (
                    <Button asChild className="gap-2">
                      <Link to="/login" onClick={() => setOpen(false)}>
                        <LogIn className="w-4 h-4" />
                        Login
                      </Link>
                    </Button>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
