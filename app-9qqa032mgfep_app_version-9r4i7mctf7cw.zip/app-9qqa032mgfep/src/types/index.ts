export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

export type UserRole = 'user' | 'admin';
export type RankType = 'none' | 'vip' | 'vip_plus' | 'premium';
export type OrderStatus = 'pending' | 'completed' | 'cancelled' | 'refunded';
export type ProductCategory = 'coins' | 'ranks' | 'offers' | 'minecraft_free' | 'minecraft_premium' | 'discord_free' | 'discord_premium';

export interface Profile {
  id: string;
  username: string;
  email: string | null;
  coins: number;
  invite_count: number;
  rank: RankType;
  role: UserRole;
  last_daily_claim: string | null;
  created_at: string;
  updated_at: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Subcategory {
  id: string;
  category_id: string;
  name: string;
  slug: string;
  description: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  coins_price: number;
  image_url: string | null;
  file_url: string | null;
  external_link: string | null;
  category: ProductCategory;
  category_id: string | null;
  subcategory_id: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Purchase {
  id: string;
  user_id: string;
  product_id: string;
  order_id: string | null;
  purchased_at: string;
}

export interface Coupon {
  id: string;
  code: string;
  coins_reward: number;
  expiry_date: string;
  is_active: boolean;
  created_at: string;
}

export interface CouponUsage {
  id: string;
  user_id: string;
  coupon_id: string;
  used_at: string;
}

export interface Transaction {
  id: string;
  user_id: string;
  type: string;
  amount: number;
  description: string | null;
  created_at: string;
}

export interface SiteSettings {
  id: string;
  site_name: string;
  bg_color_1: string;
  bg_color_2: string;
  top_players_visible: boolean;
  created_at: string;
  updated_at: string;
}

export interface CustomRole {
  id: string;
  name: string;
  permissions: string[];
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface CustomRank {
  id: string;
  name: string;
  slug: string;
  price_inr: number;
  price_coins: number;
  daily_coins: number;
  description: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface FlashSale {
  id: string;
  name: string;
  discount_percentage: number;
  product_ids: string[];
  is_active: boolean;
  starts_at: string | null;
  ends_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Order {
  id: string;
  user_id: string | null;
  items: any;
  total_amount: number;
  currency: string;
  status: OrderStatus;
  stripe_session_id: string | null;
  stripe_payment_intent_id: string | null;
  customer_email: string | null;
  customer_name: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface InviteReward {
  coins: number;
  invites: number;
  members: string;
}

