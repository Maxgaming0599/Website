-- Create categories table
CREATE TABLE public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  is_active boolean DEFAULT true NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Create subcategories table
CREATE TABLE public.subcategories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES public.categories(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  slug text NOT NULL,
  description text,
  is_active boolean DEFAULT true NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL,
  UNIQUE(category_id, slug)
);

-- Add file_url and category references to products
ALTER TABLE public.products 
  ADD COLUMN file_url text,
  ADD COLUMN category_id uuid REFERENCES public.categories(id) ON DELETE SET NULL,
  ADD COLUMN subcategory_id uuid REFERENCES public.subcategories(id) ON DELETE SET NULL;

-- Create purchases table to track who bought what
CREATE TABLE public.purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  product_id uuid REFERENCES public.products(id) ON DELETE CASCADE NOT NULL,
  order_id uuid REFERENCES public.orders(id) ON DELETE SET NULL,
  purchased_at timestamptz DEFAULT now() NOT NULL,
  UNIQUE(user_id, product_id)
);

-- Create indexes
CREATE INDEX idx_categories_slug ON public.categories(slug);
CREATE INDEX idx_subcategories_category_id ON public.subcategories(category_id);
CREATE INDEX idx_subcategories_slug ON public.subcategories(slug);
CREATE INDEX idx_products_category_id ON public.products(category_id);
CREATE INDEX idx_products_subcategory_id ON public.products(subcategory_id);
CREATE INDEX idx_purchases_user_id ON public.purchases(user_id);
CREATE INDEX idx_purchases_product_id ON public.purchases(product_id);

-- Insert default categories
INSERT INTO public.categories (name, slug, description) VALUES
  ('Minecraft', 'minecraft', 'Minecraft related items'),
  ('Discord', 'discord', 'Discord related items');

-- Insert default subcategories for Minecraft
INSERT INTO public.subcategories (category_id, name, slug, description)
SELECT id, 'Maps', 'maps', 'Minecraft maps' FROM public.categories WHERE slug = 'minecraft'
UNION ALL
SELECT id, 'Plugins', 'plugins', 'Minecraft plugins' FROM public.categories WHERE slug = 'minecraft'
UNION ALL
SELECT id, 'Setup', 'setup', 'Server setup files' FROM public.categories WHERE slug = 'minecraft'
UNION ALL
SELECT id, 'Config', 'config', 'Configuration files' FROM public.categories WHERE slug = 'minecraft'
UNION ALL
SELECT id, 'Models', 'models', '3D models' FROM public.categories WHERE slug = 'minecraft'
UNION ALL
SELECT id, 'Skript', 'skript', 'Skript files' FROM public.categories WHERE slug = 'minecraft';

-- Insert default subcategories for Discord
INSERT INTO public.subcategories (category_id, name, slug, description)
SELECT id, 'Templates', 'templates', 'Discord server templates' FROM public.categories WHERE slug = 'discord'
UNION ALL
SELECT id, 'Bots', 'bots', 'Discord bots' FROM public.categories WHERE slug = 'discord'
UNION ALL
SELECT id, 'Setup', 'setup', 'Discord setup services' FROM public.categories WHERE slug = 'discord';

-- Create storage bucket for product files
INSERT INTO storage.buckets (id, name, public)
VALUES ('app-9qqa032mgfep_products_files', 'app-9qqa032mgfep_products_files', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for product files (private - only accessible after purchase)
CREATE POLICY "Admins can upload product files"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'app-9qqa032mgfep_products_files' AND
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND role = 'admin'::public.user_role
    )
  );

CREATE POLICY "Admins can delete product files"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'app-9qqa032mgfep_products_files' AND
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND role = 'admin'::public.user_role
    )
  );

CREATE POLICY "Users can download purchased files"
  ON storage.objects FOR SELECT
  USING (
    bucket_id = 'app-9qqa032mgfep_products_files' AND
    (
      -- Admins can access all files
      EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND role = 'admin'::public.user_role
      )
      OR
      -- Users can access files they purchased
      EXISTS (
        SELECT 1 FROM public.purchases p
        JOIN public.products prod ON p.product_id = prod.id
        WHERE p.user_id = auth.uid() 
        AND prod.file_url LIKE '%' || name || '%'
      )
    )
  );

-- Enable RLS
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subcategories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.purchases ENABLE ROW LEVEL SECURITY;

-- Categories policies
CREATE POLICY "Anyone can view active categories"
  ON public.categories FOR SELECT
  USING (is_active = true);

CREATE POLICY "Admins can manage categories"
  ON public.categories FOR ALL
  USING (public.is_admin(auth.uid()));

-- Subcategories policies
CREATE POLICY "Anyone can view active subcategories"
  ON public.subcategories FOR SELECT
  USING (is_active = true);

CREATE POLICY "Admins can manage subcategories"
  ON public.subcategories FOR ALL
  USING (public.is_admin(auth.uid()));

-- Purchases policies
CREATE POLICY "Users can view their own purchases"
  ON public.purchases FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage purchases"
  ON public.purchases FOR ALL
  USING (auth.jwt()->>'role' = 'service_role');

CREATE POLICY "Admins can view all purchases"
  ON public.purchases FOR SELECT
  USING (public.is_admin(auth.uid()));