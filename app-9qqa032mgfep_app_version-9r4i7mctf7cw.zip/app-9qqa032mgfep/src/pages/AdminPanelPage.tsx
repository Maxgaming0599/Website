import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import UsersManagement from '@/components/admin/UsersManagement';
import ProductsManagement from '@/components/admin/ProductsManagement';
import CouponsManagement from '@/components/admin/CouponsManagement';
import SiteSettingsManagement from '@/components/admin/SiteSettingsManagement';
import CategoriesManagement from '@/components/admin/CategoriesManagement';

export default function AdminPanelPage() {
  const { profile, loading } = useAuth();
  const navigate = useNavigate();
  const [animating, setAnimating] = useState(true);

  useEffect(() => {
    if (!loading && profile?.role !== 'admin') {
      navigate('/home');
    }
    
    // Animation effect
    setTimeout(() => setAnimating(false), 500);
  }, [profile, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading...</p>
      </div>
    );
  }

  if (profile?.role !== 'admin') {
    return null;
  }

  return (
    <div className="min-h-screen py-8 px-4">
      <div className={`container mx-auto transition-all duration-500 ${animating ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}>
        <Card className="mb-8 border-primary/20 gaming-glow">
          <CardHeader className="text-center">
            <CardTitle className="text-4xl gradient-text">Admin Panel</CardTitle>
            <CardDescription>Manage your store</CardDescription>
          </CardHeader>
        </Card>

        <Tabs defaultValue="users" className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 mb-8">
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="categories">Categories</TabsTrigger>
            <TabsTrigger value="coupons">Coupons</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="users">
            <UsersManagement />
          </TabsContent>

          <TabsContent value="products">
            <ProductsManagement />
          </TabsContent>

          <TabsContent value="categories">
            <CategoriesManagement />
          </TabsContent>

          <TabsContent value="coupons">
            <CouponsManagement />
          </TabsContent>

          <TabsContent value="settings">
            <SiteSettingsManagement />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
