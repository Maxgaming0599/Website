export type UserRole = 'user' | 'admin';
export type RankType = 'none' | 'vip' | 'vip_plus' | 'premium';
export type OrderStatus = 'pending' | 'completed' | 'cancelled' | 'refunded';
export type ProductCategory = 'coins' | 'ranks' | 'offers' | 'minecraft_free' | 'minecraft_premium' | 'discord_free' | 'discord_premium';

export interface Profile {
  id: string;
  username: string;
  email: string | null;
  coins: number;
  invite_count: number;
  rank: RankType;
  role: UserRole;
  last_daily_claim: string | null;
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image_url: string | null;
  category: ProductCategory;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Coupon {
  id: string;
  code: string;
  coins_reward: number;
  expiry_date: string;
  is_active: boolean;
  created_at: string;
}

export interface CouponUsage {
  id: string;
  user_id: string;
  coupon_id: string;
  used_at: string;
}

export interface Transaction {
  id: string;
  user_id: string;
  type: string;
  amount: number;
  description: string | null;
  created_at: string;
}

export interface SiteSettings {
  id: string;
  site_name: string;
  bg_color_1: string;
  bg_color_2: string;
  created_at: string;
  updated_at: string;
}

export interface Order {
  id: string;
  user_id: string | null;
  items: any;
  total_amount: number;
  currency: string;
  status: OrderStatus;
  stripe_session_id: string | null;
  stripe_payment_intent_id: string | null;
  customer_email: string | null;
  customer_name: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface InviteReward {
  coins: number;
  invites: number;
  members: string;
}
