import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { getAllCustomRoles, createCustomRole, updateCustomRole, deleteCustomRole, getAllCustomRanks, createCustomRank, updateCustomRank, deleteCustomRank } from '@/db/api';
import type { CustomRole, CustomRank } from '@/types';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, Crown, Shield } from 'lucide-react';

export default function OwnerPanelPage() {
  const { profile, loading } = useAuth();
  const navigate = useNavigate();
  const [isOwner, setIsOwner] = useState(false);
  
  // Roles state
  const [roles, setRoles] = useState<CustomRole[]>([]);
  const [roleDialogOpen, setRoleDialogOpen] = useState(false);
  const [editingRole, setEditingRole] = useState<CustomRole | null>(null);
  const [roleName, setRoleName] = useState('');
  
  // Ranks state
  const [ranks, setRanks] = useState<CustomRank[]>([]);
  const [rankDialogOpen, setRankDialogOpen] = useState(false);
  const [editingRank, setEditingRank] = useState<CustomRank | null>(null);
  const [rankName, setRankName] = useState('');
  const [rankSlug, setRankSlug] = useState('');
  const [rankPriceInr, setRankPriceInr] = useState('');
  const [rankPriceCoins, setRankPriceCoins] = useState('');
  const [rankDailyCoins, setRankDailyCoins] = useState('');
  const [rankDescription, setRankDescription] = useState('');

  useEffect(() => {
    checkOwnerStatus();
  }, [profile, loading]);

  const checkOwnerStatus = async () => {
    if (!loading && profile) {
      // Check if user is owner (you can implement get_owner_id check here)
      // For now, checking if role is admin and created_at is earliest
      setIsOwner(profile.role === 'admin');
      if (profile.role === 'admin') {
        loadData();
      } else {
        navigate('/home');
      }
    } else if (!loading) {
      navigate('/login');
    }
  };

  const loadData = async () => {
    const [rolesData, ranksData] = await Promise.all([
      getAllCustomRoles(),
      getAllCustomRanks()
    ]);
    setRoles(rolesData);
    setRanks(ranksData);
  };

  // Role functions
  const resetRoleForm = () => {
    setRoleName('');
    setEditingRole(null);
  };

  const handleOpenRoleDialog = (role?: CustomRole) => {
    if (role) {
      setEditingRole(role);
      setRoleName(role.name);
    } else {
      resetRoleForm();
    }
    setRoleDialogOpen(true);
  };

  const handleSubmitRole = async () => {
    if (!roleName) {
      toast.error('Please enter role name');
      return;
    }

    const roleData = {
      name: roleName,
      permissions: []
    };

    let success = false;
    if (editingRole) {
      success = await updateCustomRole(editingRole.id, roleData);
      if (success) toast.success('Role updated successfully');
    } else {
      const result = await createCustomRole(roleData);
      success = !!result;
      if (success) toast.success('Role created successfully');
    }

    if (success) {
      loadData();
      setRoleDialogOpen(false);
      resetRoleForm();
    } else {
      toast.error('Failed to save role');
    }
  };

  const handleDeleteRole = async (roleId: string) => {
    if (!confirm('Are you sure you want to delete this role?')) return;

    const success = await deleteCustomRole(roleId);
    if (success) {
      toast.success('Role deleted successfully');
      loadData();
    } else {
      toast.error('Failed to delete role');
    }
  };

  // Rank functions
  const resetRankForm = () => {
    setRankName('');
    setRankSlug('');
    setRankPriceInr('');
    setRankPriceCoins('');
    setRankDailyCoins('');
    setRankDescription('');
    setEditingRank(null);
  };

  const handleOpenRankDialog = (rank?: CustomRank) => {
    if (rank) {
      setEditingRank(rank);
      setRankName(rank.name);
      setRankSlug(rank.slug);
      setRankPriceInr(rank.price_inr.toString());
      setRankPriceCoins(rank.price_coins.toString());
      setRankDailyCoins(rank.daily_coins.toString());
      setRankDescription(rank.description || '');
    } else {
      resetRankForm();
    }
    setRankDialogOpen(true);
  };

  const generateSlug = (name: string) => {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
  };

  const handleRankNameChange = (name: string) => {
    setRankName(name);
    if (!editingRank) {
      setRankSlug(generateSlug(name));
    }
  };

  const handleSubmitRank = async () => {
    if (!rankName || !rankSlug || !rankPriceInr || !rankDailyCoins) {
      toast.error('Please fill in all required fields');
      return;
    }

    const rankData = {
      name: rankName,
      slug: rankSlug,
      price_inr: parseFloat(rankPriceInr),
      price_coins: rankPriceCoins ? parseFloat(rankPriceCoins) : 0,
      daily_coins: parseInt(rankDailyCoins),
      description: rankDescription || null
    };

    let success = false;
    if (editingRank) {
      success = await updateCustomRank(editingRank.id, rankData);
      if (success) toast.success('Rank updated successfully');
    } else {
      const result = await createCustomRank(rankData);
      success = !!result;
      if (success) toast.success('Rank created successfully');
    }

    if (success) {
      loadData();
      setRankDialogOpen(false);
      resetRankForm();
    } else {
      toast.error('Failed to save rank');
    }
  };

  const handleDeleteRank = async (rankId: string) => {
    if (!confirm('Are you sure you want to delete this rank?')) return;

    const success = await deleteCustomRank(rankId);
    if (success) {
      toast.success('Rank deleted successfully');
      loadData();
    } else {
      toast.error('Failed to delete rank');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading...</p>
      </div>
    );
  }

  if (!isOwner) {
    return null;
  }

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto">
        <Card className="mb-8 border-primary/20 gaming-glow">
          <CardHeader className="text-center">
            <CardTitle className="text-4xl gradient-text flex items-center justify-center gap-2">
              <Crown className="w-10 h-10" />
              Owner Panel
            </CardTitle>
            <CardDescription>Manage roles, ranks, and system configuration</CardDescription>
          </CardHeader>
        </Card>

        <Tabs defaultValue="ranks" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="ranks" className="gap-2">
              <Crown className="w-4 h-4" />
              Ranks
            </TabsTrigger>
            <TabsTrigger value="roles" className="gap-2">
              <Shield className="w-4 h-4" />
              Roles
            </TabsTrigger>
          </TabsList>

          {/* Ranks Tab */}
          <TabsContent value="ranks">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Rank Management</CardTitle>
                    <CardDescription>Create and configure ranks with coin rewards</CardDescription>
                  </div>
                  <Dialog open={rankDialogOpen} onOpenChange={(open) => {
                    setRankDialogOpen(open);
                    if (!open) resetRankForm();
                  }}>
                    <DialogTrigger asChild>
                      <Button onClick={() => handleOpenRankDialog()} className="gap-2">
                        <Plus className="w-4 h-4" />
                        Add Rank
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>{editingRank ? 'Edit Rank' : 'Add New Rank'}</DialogTitle>
                        <DialogDescription>
                          Configure rank pricing and daily coin rewards
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 max-h-[60vh] overflow-y-auto">
                        <div className="space-y-2">
                          <Label>Rank Name *</Label>
                          <Input
                            placeholder="VIP, Premium, etc."
                            value={rankName}
                            onChange={(e) => handleRankNameChange(e.target.value)}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Slug *</Label>
                          <Input
                            placeholder="vip, premium, etc."
                            value={rankSlug}
                            onChange={(e) => setRankSlug(e.target.value)}
                          />
                          <p className="text-xs text-muted-foreground">Used internally (lowercase, underscores)</p>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Price (₹) *</Label>
                            <Input
                              type="number"
                              placeholder="0"
                              value={rankPriceInr}
                              onChange={(e) => setRankPriceInr(e.target.value)}
                              min="0"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Price (Coins)</Label>
                            <Input
                              type="number"
                              placeholder="0"
                              value={rankPriceCoins}
                              onChange={(e) => setRankPriceCoins(e.target.value)}
                              min="0"
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label>Daily Coins Reward *</Label>
                          <Input
                            type="number"
                            placeholder="100"
                            value={rankDailyCoins}
                            onChange={(e) => setRankDailyCoins(e.target.value)}
                            min="0"
                          />
                          <p className="text-xs text-muted-foreground">Coins users receive daily with this rank</p>
                        </div>
                        <div className="space-y-2">
                          <Label>Description</Label>
                          <Textarea
                            placeholder="Rank benefits and features"
                            value={rankDescription}
                            onChange={(e) => setRankDescription(e.target.value)}
                          />
                        </div>
                        <Button onClick={handleSubmitRank} className="w-full">
                          {editingRank ? 'Update Rank' : 'Create Rank'}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Slug</TableHead>
                      <TableHead>Price (₹)</TableHead>
                      <TableHead>Price (Coins)</TableHead>
                      <TableHead>Daily Coins</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {ranks.map((rank) => (
                      <TableRow key={rank.id}>
                        <TableCell className="font-medium">{rank.name}</TableCell>
                        <TableCell>{rank.slug}</TableCell>
                        <TableCell>₹{rank.price_inr}</TableCell>
                        <TableCell>{rank.price_coins > 0 ? `${rank.price_coins} coins` : '-'}</TableCell>
                        <TableCell>{rank.daily_coins} coins</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleOpenRankDialog(rank)}
                            >
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDeleteRank(rank.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Roles Tab */}
          <TabsContent value="roles">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Role Management</CardTitle>
                    <CardDescription>Create and manage custom user roles</CardDescription>
                  </div>
                  <Dialog open={roleDialogOpen} onOpenChange={(open) => {
                    setRoleDialogOpen(open);
                    if (!open) resetRoleForm();
                  }}>
                    <DialogTrigger asChild>
                      <Button onClick={() => handleOpenRoleDialog()} className="gap-2">
                        <Plus className="w-4 h-4" />
                        Add Role
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>{editingRole ? 'Edit Role' : 'Add New Role'}</DialogTitle>
                        <DialogDescription>
                          Create custom roles for your users
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label>Role Name *</Label>
                          <Input
                            placeholder="Moderator, Helper, etc."
                            value={roleName}
                            onChange={(e) => setRoleName(e.target.value)}
                          />
                        </div>
                        <Button onClick={handleSubmitRole} className="w-full">
                          {editingRole ? 'Update Role' : 'Create Role'}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Created</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {roles.map((role) => (
                      <TableRow key={role.id}>
                        <TableCell className="font-medium">{role.name}</TableCell>
                        <TableCell>{new Date(role.created_at).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleOpenRoleDialog(role)}
                            >
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDeleteRole(role.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
