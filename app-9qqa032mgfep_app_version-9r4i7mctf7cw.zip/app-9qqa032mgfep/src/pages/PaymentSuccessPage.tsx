import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { verifyPayment, getOrderBySessionId } from '@/db/api';
import { useAuth } from '@/contexts/AuthContext';

export default function PaymentSuccessPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { refreshProfile } = useAuth();
  const sessionId = searchParams.get('session_id');
  const [verifying, setVerifying] = useState(true);
  const [verified, setVerified] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [orderDetails, setOrderDetails] = useState<any>(null);

  useEffect(() => {
    if (sessionId) {
      verifyPaymentSession();
    } else {
      setError('No session ID found');
      setVerifying(false);
    }
  }, [sessionId]);

  const verifyPaymentSession = async () => {
    if (!sessionId) return;

    try {
      const result = await verifyPayment(sessionId);
      
      if (result?.verified) {
        setVerified(true);
        const order = await getOrderBySessionId(sessionId);
        setOrderDetails(order);
        
        // Refresh profile to get updated coins/rank
        await refreshProfile();
      } else {
        setError('Payment not completed');
      }
    } catch (err) {
      setError('Failed to verify payment');
    } finally {
      setVerifying(false);
    }
  };

  if (verifying) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <Loader2 className="w-16 h-16 animate-spin mx-auto mb-4 text-primary" />
            <p className="text-lg">Verifying your payment...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          {verified ? (
            <>
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <CardTitle className="text-2xl text-green-600">Payment Successful!</CardTitle>
              <CardDescription>Your purchase has been completed</CardDescription>
            </>
          ) : (
            <>
              <XCircle className="w-16 h-16 text-destructive mx-auto mb-4" />
              <CardTitle className="text-2xl text-destructive">Payment Failed</CardTitle>
              <CardDescription>{error || 'Something went wrong'}</CardDescription>
            </>
          )}
        </CardHeader>
        <CardContent className="space-y-4">
          {verified && orderDetails && (
            <div className="space-y-2 text-sm">
              <p><strong>Order ID:</strong> {orderDetails.id}</p>
              <p><strong>Amount:</strong> ₹{orderDetails.total_amount}</p>
              <p><strong>Status:</strong> {orderDetails.status}</p>
            </div>
          )}
          <div className="flex gap-2">
            <Button onClick={() => navigate('/home')} className="flex-1">
              Go to Home
            </Button>
            <Button onClick={() => navigate('/store')} variant="outline" className="flex-1">
              Continue Shopping
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
