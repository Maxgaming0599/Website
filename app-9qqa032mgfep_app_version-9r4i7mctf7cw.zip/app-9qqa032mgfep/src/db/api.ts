import { supabase } from './supabase';
import type { Profile, Product, Coupon, Transaction, SiteSettings, Order, ProductCategory, RankType, Category, Subcategory, Purchase } from '@/types';

// Profile APIs
export async function getProfile(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();

  if (error) {
    console.error('Error fetching profile:', error);
    return null;
  }
  return data;
}

export async function getAllProfiles(): Promise<Profile[]> {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching profiles:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

export async function updateProfile(userId: string, updates: Partial<Profile>): Promise<boolean> {
  const { error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId);

  if (error) {
    console.error('Error updating profile:', error);
    return false;
  }
  return true;
}

// Product APIs
export async function getProducts(category?: ProductCategory): Promise<Product[]> {
  let query = supabase
    .from('products')
    .select('*')
    .eq('is_active', true)
    .order('created_at', { ascending: false });

  if (category) {
    query = query.eq('category', category);
  }

  const { data, error } = await query;

  if (error) {
    console.error('Error fetching products:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

export async function getAllProducts(): Promise<Product[]> {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching all products:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

export async function createProduct(product: Omit<Product, 'id' | 'created_at' | 'updated_at'>): Promise<Product | null> {
  const { data, error } = await supabase
    .from('products')
    .insert(product)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating product:', error);
    return null;
  }
  return data;
}

export async function updateProduct(productId: string, updates: Partial<Product>): Promise<boolean> {
  const { error } = await supabase
    .from('products')
    .update(updates)
    .eq('id', productId);

  if (error) {
    console.error('Error updating product:', error);
    return false;
  }
  return true;
}

export async function deleteProduct(productId: string): Promise<boolean> {
  const { error } = await supabase
    .from('products')
    .delete()
    .eq('id', productId);

  if (error) {
    console.error('Error deleting product:', error);
    return false;
  }
  return true;
}

// Coupon APIs
export async function getCoupons(): Promise<Coupon[]> {
  const { data, error } = await supabase
    .from('coupons')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching coupons:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

export async function createCoupon(coupon: Omit<Coupon, 'id' | 'created_at'>): Promise<Coupon | null> {
  const { data, error } = await supabase
    .from('coupons')
    .insert(coupon)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating coupon:', error);
    return null;
  }
  return data;
}

export async function deleteCoupon(couponId: string): Promise<boolean> {
  const { error } = await supabase
    .from('coupons')
    .delete()
    .eq('id', couponId);

  if (error) {
    console.error('Error deleting coupon:', error);
    return false;
  }
  return true;
}

export async function redeemCoupon(userId: string, couponCode: string): Promise<{ success: boolean; message: string; reward?: number }> {
  const { data, error } = await supabase.rpc('redeem_coupon', {
    p_user_id: userId,
    p_coupon_code: couponCode
  });

  if (error) {
    console.error('Error redeeming coupon:', error);
    return { success: false, message: 'Failed to redeem coupon' };
  }

  return data;
}

// Transaction APIs
export async function getTransactions(userId: string): Promise<Transaction[]> {
  const { data, error } = await supabase
    .from('transactions')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(50);

  if (error) {
    console.error('Error fetching transactions:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

// Coin management APIs
export async function addCoins(userId: string, amount: number): Promise<boolean> {
  const { error } = await supabase.rpc('add_coins', {
    p_user_id: userId,
    p_amount: amount
  });

  if (error) {
    console.error('Error adding coins:', error);
    return false;
  }
  return true;
}

export async function removeCoins(userId: string, amount: number): Promise<boolean> {
  const { error } = await supabase.rpc('remove_coins', {
    p_user_id: userId,
    p_amount: amount
  });

  if (error) {
    console.error('Error removing coins:', error);
    return false;
  }
  return true;
}

export async function claimDailyReward(userId: string): Promise<{ success: boolean; message?: string; reward?: number; next_claim?: string }> {
  const { data, error } = await supabase.rpc('claim_daily_reward', {
    p_user_id: userId
  });

  if (error) {
    console.error('Error claiming daily reward:', error);
    return { success: false, message: 'Failed to claim reward' };
  }

  return data;
}

export async function claimAfkReward(userId: string): Promise<{ success: boolean; message?: string; reward?: number }> {
  const { data, error } = await supabase.rpc('claim_afk_reward', {
    p_user_id: userId
  });

  if (error) {
    console.error('Error claiming AFK reward:', error);
    return { success: false, message: 'Failed to claim reward' };
  }

  return data;
}

// Site settings APIs
export async function getSiteSettings(): Promise<SiteSettings | null> {
  const { data, error } = await supabase
    .from('site_settings')
    .select('*')
    .limit(1)
    .maybeSingle();

  if (error) {
    console.error('Error fetching site settings:', error);
    return null;
  }
  return data;
}

export async function updateSiteSettings(settingsId: string, updates: Partial<SiteSettings>): Promise<boolean> {
  const { error } = await supabase
    .from('site_settings')
    .update(updates)
    .eq('id', settingsId);

  if (error) {
    console.error('Error updating site settings:', error);
    return false;
  }
  return true;
}

// Order APIs
export async function getOrders(userId: string): Promise<Order[]> {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching orders:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

export async function getOrderBySessionId(sessionId: string): Promise<Order | null> {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .eq('stripe_session_id', sessionId)
    .maybeSingle();

  if (error) {
    console.error('Error fetching order:', error);
    return null;
  }
  return data;
}

// Rank management
export async function updateUserRank(userId: string, rank: RankType): Promise<boolean> {
  const { error } = await supabase
    .from('profiles')
    .update({ rank })
    .eq('id', userId);

  if (error) {
    console.error('Error updating rank:', error);
    return false;
  }
  return true;
}

// Admin management
export async function updateUserRole(userId: string, role: 'user' | 'admin'): Promise<boolean> {
  const { error } = await supabase
    .from('profiles')
    .update({ role })
    .eq('id', userId);

  if (error) {
    console.error('Error updating role:', error);
    return false;
  }
  return true;
}

// Payment APIs
export async function createCheckoutSession(items: any[], currency = 'inr'): Promise<{ url: string; sessionId: string; orderId: string } | null> {
  const { data, error } = await supabase.functions.invoke('create_stripe_checkout', {
    body: { items, currency }
  });

  if (error) {
    const errorMsg = await error?.context?.text();
    console.error('Error creating checkout session:', errorMsg || error?.message);
    return null;
  }

  return data?.data || null;
}

export async function verifyPayment(sessionId: string): Promise<any> {
  const { data, error } = await supabase.functions.invoke('verify_stripe_payment', {
    body: { sessionId }
  });

  if (error) {
    const errorMsg = await error?.context?.text();
    console.error('Error verifying payment:', errorMsg || error?.message);
    return null;
  }

  return data?.data || null;
}

// ============================================
// CATEGORY FUNCTIONS
// ============================================

export async function getAllCategories(): Promise<Category[]> {
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .eq('is_active', true)
    .order('name');

  if (error) {
    console.error('Error fetching categories:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function createCategory(category: { name: string; slug: string; description?: string }) {
  const { data, error } = await supabase
    .from('categories')
    .insert([category])
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating category:', error);
    return null;
  }

  return data;
}

export async function updateCategory(id: string, updates: Partial<Category>) {
  const { error } = await supabase
    .from('categories')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id);

  return !error;
}

export async function deleteCategory(id: string) {
  const { error } = await supabase
    .from('categories')
    .delete()
    .eq('id', id);

  return !error;
}

// ============================================
// SUBCATEGORY FUNCTIONS
// ============================================

export async function getSubcategoriesByCategory(categoryId: string): Promise<Subcategory[]> {
  const { data, error } = await supabase
    .from('subcategories')
    .select('*')
    .eq('category_id', categoryId)
    .eq('is_active', true)
    .order('name');

  if (error) {
    console.error('Error fetching subcategories:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function getAllSubcategories(): Promise<Subcategory[]> {
  const { data, error } = await supabase
    .from('subcategories')
    .select('*')
    .eq('is_active', true)
    .order('name');

  if (error) {
    console.error('Error fetching subcategories:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function createSubcategory(subcategory: { category_id: string; name: string; slug: string; description?: string }) {
  const { data, error } = await supabase
    .from('subcategories')
    .insert([subcategory])
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating subcategory:', error);
    return null;
  }

  return data;
}

export async function updateSubcategory(id: string, updates: Partial<Subcategory>) {
  const { error } = await supabase
    .from('subcategories')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id);

  return !error;
}

export async function deleteSubcategory(id: string) {
  const { error } = await supabase
    .from('subcategories')
    .delete()
    .eq('id', id);

  return !error;
}

// ============================================
// PURCHASE FUNCTIONS
// ============================================

export async function getUserPurchases(userId: string): Promise<Purchase[]> {
  const { data, error } = await supabase
    .from('purchases')
    .select('*')
    .eq('user_id', userId)
    .order('purchased_at', { ascending: false });

  if (error) {
    console.error('Error fetching purchases:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function getUserPurchasedProducts(userId: string): Promise<Product[]> {
  const { data, error } = await supabase
    .from('purchases')
    .select('product_id, products(*)')
    .eq('user_id', userId)
    .order('purchased_at', { ascending: false });

  if (error) {
    console.error('Error fetching purchased products:', error);
    return [];
  }

  return Array.isArray(data) ? data.map((p: any) => p.products).filter(Boolean) : [];
}

export async function checkUserPurchase(userId: string, productId: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('purchases')
    .select('id')
    .eq('user_id', userId)
    .eq('product_id', productId)
    .maybeSingle();

  if (error) {
    console.error('Error checking purchase:', error);
    return false;
  }

  return !!data;
}

export async function downloadProductFile(fileUrl: string): Promise<Blob | null> {
  try {
    // Extract the file path from the full URL
    const urlParts = fileUrl.split('/');
    const fileName = urlParts[urlParts.length - 1];

    const { data, error } = await supabase.storage
      .from('app-9qqa032mgfep_products_files')
      .download(fileName);

    if (error) {
      console.error('Error downloading file:', error);
      return null;
    }

    return data;
  } catch (error) {
    console.error('Error downloading file:', error);
    return null;
  }
}

// ============================================
// CUSTOM ROLES & RANKS FUNCTIONS
// ============================================

export async function getAllCustomRoles() {
  const { data, error } = await supabase
    .from('custom_roles')
    .select('*')
    .eq('is_active', true)
    .order('name');

  if (error) {
    console.error('Error fetching custom roles:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function createCustomRole(role: { name: string; permissions: string[] }) {
  const { data, error } = await supabase
    .from('custom_roles')
    .insert([role])
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating custom role:', error);
    return null;
  }

  return data;
}

export async function updateCustomRole(id: string, updates: any) {
  const { error } = await supabase
    .from('custom_roles')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id);

  return !error;
}

export async function deleteCustomRole(id: string) {
  const { error } = await supabase
    .from('custom_roles')
    .delete()
    .eq('id', id);

  return !error;
}

export async function getAllCustomRanks() {
  const { data, error } = await supabase
    .from('custom_ranks')
    .select('*')
    .eq('is_active', true)
    .order('price_inr');

  if (error) {
    console.error('Error fetching custom ranks:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function createCustomRank(rank: any) {
  const { data, error } = await supabase
    .from('custom_ranks')
    .insert([rank])
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating custom rank:', error);
    return null;
  }

  return data;
}

export async function updateCustomRank(id: string, updates: any) {
  const { error } = await supabase
    .from('custom_ranks')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id);

  return !error;
}

export async function deleteCustomRank(id: string) {
  const { error } = await supabase
    .from('custom_ranks')
    .delete()
    .eq('id', id);

  return !error;
}

// ============================================
// FLASH SALE FUNCTIONS
// ============================================

export async function getAllFlashSales() {
  const { data, error } = await supabase
    .from('flash_sales')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching flash sales:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function getActiveFlashSale() {
  const { data, error } = await supabase
    .from('flash_sales')
    .select('*')
    .eq('is_active', true)
    .maybeSingle();

  if (error) {
    console.error('Error fetching active flash sale:', error);
    return null;
  }

  return data;
}

export async function createFlashSale(sale: any) {
  const { data, error } = await supabase
    .from('flash_sales')
    .insert([sale])
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating flash sale:', error);
    return null;
  }

  return data;
}

export async function updateFlashSale(id: string, updates: any) {
  const { error } = await supabase
    .from('flash_sales')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id);

  return !error;
}

export async function deleteFlashSale(id: string) {
  const { error } = await supabase
    .from('flash_sales')
    .delete()
    .eq('id', id);

  return !error;
}

// ============================================
// ANALYTICS FUNCTIONS
// ============================================

export async function getTopPlayersByCoins(limit = 10) {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, username, coins, rank')
    .order('coins', { ascending: false })
    .limit(limit);

  if (error) {
    console.error('Error fetching top players:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

// ============================================
// COIN PURCHASE FUNCTIONS
// ============================================

export async function buyProductWithCoins(productId: string) {
  const { data, error } = await supabase.rpc('buy_with_coins', {
    p_user_id: (await supabase.auth.getUser()).data.user?.id,
    p_product_id: productId
  });

  if (error) {
    console.error('Error buying product with coins:', error);
    return false;
  }

  return data;
}

export async function buyRankWithCoins(rankSlug: string) {
  const { data, error } = await supabase.rpc('buy_rank_with_coins', {
    p_user_id: (await supabase.auth.getUser()).data.user?.id,
    p_rank_slug: rankSlug
  });

  if (error) {
    console.error('Error buying rank with coins:', error);
    return false;
  }

  return data;
}

