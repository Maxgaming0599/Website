import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function LoadingPage() {
  const navigate = useNavigate();
  const [show, setShow] = useState(false);

  useEffect(() => {
    // Trigger animation
    setTimeout(() => setShow(true), 100);
    
    // Navigate to home after animation
    const timer = setTimeout(() => {
      navigate('/home');
    }, 3000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center gradient-bg">
      <div className={`transition-all duration-1000 ${show ? 'opacity-100 scale-100' : 'opacity-0 scale-50'}`}>
        <h1 className="text-6xl md:text-8xl font-bold text-white animate-pulse-glow">
          MineMart
        </h1>
      </div>
    </div>
  );
}
