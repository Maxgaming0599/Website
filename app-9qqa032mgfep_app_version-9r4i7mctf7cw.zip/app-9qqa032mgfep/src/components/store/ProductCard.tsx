import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { Product } from '@/types';
import { createCheckoutSession } from '@/db/api';
import { toast } from 'sonner';
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);

  const handlePurchase = async () => {
    if (!user) {
      toast.error('Please login to make a purchase');
      return;
    }

    // Handle free products
    if (product.price === 0) {
      toast.success('Free item claimed!');
      return;
    }

    setLoading(true);
    try {
      const result = await createCheckoutSession([
        {
          name: product.name,
          price: product.price,
          quantity: 1,
          image_url: product.image_url || undefined,
          product_id: product.id
        }
      ]);

      if (result?.url) {
        window.open(result.url, '_blank');
      } else {
        toast.error('Failed to create checkout session. Please ensure STRIPE_SECRET_KEY is configured.');
      }
    } catch (error) {
      toast.error('Failed to process purchase');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      {product.image_url && (
        <div className="aspect-video w-full overflow-hidden rounded-t-lg">
          <img 
            src={product.image_url} 
            alt={product.name}
            className="w-full h-full object-cover"
          />
        </div>
      )}
      <CardHeader>
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-xl">{product.name}</CardTitle>
          <Badge variant="secondary">
            {product.price === 0 ? 'FREE' : `₹${product.price}`}
          </Badge>
        </div>
        {product.description && (
          <CardDescription>{product.description}</CardDescription>
        )}
      </CardHeader>
      <CardFooter>
        <Button onClick={handlePurchase} disabled={loading} className="w-full">
          {loading ? 'Processing...' : product.price === 0 ? 'Get Free' : 'Purchase'}
        </Button>
      </CardFooter>
    </Card>
  );
}
