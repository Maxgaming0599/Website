import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { getAllProducts, createProduct, updateProduct, deleteProduct, getAllCategories, getSubcategoriesByCategory } from '@/db/api';
import { supabase } from '@/db/supabase';
import type { Product, ProductCategory, Category, Subcategory } from '@/types';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, Download } from 'lucide-react';

export default function ProductsManagement() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [coinsPrice, setCoinsPrice] = useState('');
  const [externalLink, setExternalLink] = useState('');
  const [category, setCategory] = useState<ProductCategory>('coins');
  const [categoryId, setCategoryId] = useState('none');
  const [subcategoryId, setSubcategoryId] = useState('none');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [productFile, setProductFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (categoryId && categoryId !== 'none') {
      loadSubcategories(categoryId);
    } else {
      setSubcategories([]);
      setSubcategoryId('none');
    }
  }, [categoryId]);

  const loadData = async () => {
    setLoading(true);
    const [prods, cats] = await Promise.all([
      getAllProducts(),
      getAllCategories()
    ]);
    setProducts(prods);
    setCategories(cats);
    setLoading(false);
  };

  const loadSubcategories = async (catId: string) => {
    const subs = await getSubcategoriesByCategory(catId);
    setSubcategories(subs);
  };

  const resetForm = () => {
    setName('');
    setDescription('');
    setPrice('');
    setCoinsPrice('');
    setExternalLink('');
    setCategory('coins');
    setCategoryId('none');
    setSubcategoryId('none');
    setImageFile(null);
    setProductFile(null);
    setEditingProduct(null);
  };

  const handleOpenDialog = (product?: Product) => {
    if (product) {
      setEditingProduct(product);
      setName(product.name);
      setDescription(product.description || '');
      setPrice(product.price.toString());
      setCoinsPrice(product.coins_price?.toString() || '');
      setExternalLink(product.external_link || '');
      setCategory(product.category);
      setCategoryId(product.category_id || 'none');
      setSubcategoryId(product.subcategory_id || 'none');
      if (product.category_id) {
        loadSubcategories(product.category_id);
      }
    } else {
      resetForm();
    }
    setDialogOpen(true);
  };

  const uploadImage = async (file: File): Promise<string | null> => {
    try {
      // Validate file size (max 1MB)
      if (file.size > 1024 * 1024) {
        toast.error('Image size must be less than 1MB');
        return null;
      }

      // Validate file type
      if (!file.type.startsWith('image/')) {
        toast.error('Please upload an image file');
        return null;
      }

      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}_${Date.now()}.${fileExt}`;
      
      const { error } = await supabase.storage
        .from('app-9qqa032mgfep_products_images')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) {
        console.error('Upload error:', error);
        toast.error(`Upload failed: ${error.message}`);
        return null;
      }

      const { data: urlData } = supabase.storage
        .from('app-9qqa032mgfep_products_images')
        .getPublicUrl(fileName);

      toast.success('Image uploaded successfully');
      return urlData.publicUrl;
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload image');
      return null;
    }
  };

  const uploadFile = async (file: File): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}_${Date.now()}.${fileExt}`;
      
      const { error } = await supabase.storage
        .from('app-9qqa032mgfep_products_files')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) {
        console.error('File upload error:', error);
        toast.error(`File upload failed: ${error.message}`);
        return null;
      }

      const { data: urlData } = supabase.storage
        .from('app-9qqa032mgfep_products_files')
        .getPublicUrl(fileName);

      toast.success('File uploaded successfully');
      return urlData.publicUrl;
    } catch (error) {
      console.error('File upload error:', error);
      toast.error('Failed to upload file');
      return null;
    }
  };

  const handleSubmit = async () => {
    if (!name || price === '') {
      toast.error('Please fill in all required fields');
      return;
    }

    const priceNum = parseFloat(price);
    if (isNaN(priceNum) || priceNum < 0) {
      toast.error('Please enter a valid price (0 or greater)');
      return;
    }

    let imageUrl = editingProduct?.image_url || null;
    let fileUrl = editingProduct?.file_url || null;

    setUploading(true);

    // Upload image if provided
    if (imageFile) {
      imageUrl = await uploadImage(imageFile);
      if (!imageUrl) {
        setUploading(false);
        return;
      }
    }

    // Upload product file if provided
    if (productFile) {
      fileUrl = await uploadFile(productFile);
      if (!fileUrl) {
        setUploading(false);
        return;
      }
    }

    setUploading(false);

    const productData = {
      name,
      description: description || null,
      price: priceNum,
      coins_price: coinsPrice ? parseInt(coinsPrice) : 0,
      external_link: externalLink || null,
      category,
      category_id: categoryId !== 'none' ? categoryId : null,
      subcategory_id: subcategoryId !== 'none' ? subcategoryId : null,
      image_url: imageUrl,
      file_url: fileUrl,
      is_active: true
    };

    let success = false;
    if (editingProduct) {
      success = await updateProduct(editingProduct.id, productData);
      if (success) toast.success('Product updated successfully');
    } else {
      const result = await createProduct(productData);
      success = !!result;
      if (success) toast.success('Product created successfully');
    }

    if (success) {
      loadData();
      setDialogOpen(false);
      resetForm();
    } else {
      toast.error('Failed to save product');
    }
  };

  const handleDelete = async (productId: string) => {
    if (!confirm('Are you sure you want to delete this product?')) return;

    const success = await deleteProduct(productId);
    if (success) {
      toast.success('Product deleted successfully');
      loadData();
    } else {
      toast.error('Failed to delete product');
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Products Management</CardTitle>
              <CardDescription>Add and manage store products</CardDescription>
            </div>
            <Dialog open={dialogOpen} onOpenChange={(open) => {
              setDialogOpen(open);
              if (!open) resetForm();
            }}>
              <DialogTrigger asChild>
                <Button onClick={() => handleOpenDialog()} className="gap-2">
                  <Plus className="w-4 h-4" />
                  Add Product
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>{editingProduct ? 'Edit Product' : 'Add New Product'}</DialogTitle>
                  <DialogDescription>
                    {editingProduct ? 'Update product details' : 'Create a new product for your store'}
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 max-h-[60vh] overflow-y-auto">
                  <div className="space-y-2">
                    <Label>Name *</Label>
                    <Input
                      placeholder="Product name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Textarea
                      placeholder="Product description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Price (₹) *</Label>
                    <Input
                      type="number"
                      placeholder="0.00 (Enter 0 for free items)"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                    <p className="text-xs text-muted-foreground">Set to 0 for free items</p>
                  </div>
                  <div className="space-y-2">
                    <Label>Coins Price (Optional)</Label>
                    <Input
                      type="number"
                      placeholder="0 (coins required to purchase)"
                      value={coinsPrice}
                      onChange={(e) => setCoinsPrice(e.target.value)}
                      min="0"
                    />
                    <p className="text-xs text-muted-foreground">Allow users to buy with coins</p>
                  </div>
                  <div className="space-y-2">
                    <Label>External Link (Optional)</Label>
                    <Input
                      type="url"
                      placeholder="https://example.com"
                      value={externalLink}
                      onChange={(e) => setExternalLink(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">If provided, opens this link instead of downloading file</p>
                  </div>
                  <div className="space-y-2">
                    <Label>Legacy Category *</Label>
                    <Select value={category} onValueChange={(value) => setCategory(value as ProductCategory)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="coins">Coins</SelectItem>
                        <SelectItem value="ranks">Ranks</SelectItem>
                        <SelectItem value="offers">Offers</SelectItem>
                        <SelectItem value="minecraft_free">Minecraft Free</SelectItem>
                        <SelectItem value="minecraft_premium">Minecraft Premium</SelectItem>
                        <SelectItem value="discord_free">Discord Free</SelectItem>
                        <SelectItem value="discord_premium">Discord Premium</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Category (Optional)</Label>
                    <Select value={categoryId} onValueChange={setCategoryId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {categories.map((cat) => (
                          <SelectItem key={cat.id} value={cat.id}>
                            {cat.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {categoryId && categoryId !== 'none' && subcategories.length > 0 && (
                    <div className="space-y-2">
                      <Label>Subcategory (Optional)</Label>
                      <Select value={subcategoryId} onValueChange={setSubcategoryId}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select subcategory" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">None</SelectItem>
                          {subcategories.map((sub) => (
                            <SelectItem key={sub.id} value={sub.id}>
                              {sub.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  <div className="space-y-2">
                    <Label>Product Image</Label>
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={(e) => setImageFile(e.target.files?.[0] || null)}
                      disabled={uploading}
                    />
                    {imageFile && (
                      <p className="text-xs text-muted-foreground">
                        Selected: {imageFile.name} ({(imageFile.size / 1024).toFixed(2)} KB)
                      </p>
                    )}
                    {editingProduct?.image_url && !imageFile && (
                      <div className="mt-2">
                        <p className="text-xs text-muted-foreground mb-2">Current image:</p>
                        <img 
                          src={editingProduct.image_url} 
                          alt="Current product" 
                          className="w-32 h-32 object-cover rounded border"
                        />
                      </div>
                    )}
                    <p className="text-xs text-muted-foreground">
                      Max size: 1MB. Supported formats: JPG, PNG, GIF, WEBP
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>Downloadable File (Optional)</Label>
                    <Input
                      type="file"
                      onChange={(e) => setProductFile(e.target.files?.[0] || null)}
                      disabled={uploading}
                    />
                    {productFile && (
                      <p className="text-xs text-muted-foreground">
                        Selected: {productFile.name} ({(productFile.size / 1024 / 1024).toFixed(2)} MB)
                      </p>
                    )}
                    {editingProduct?.file_url && !productFile && (
                      <div className="mt-2 flex items-center gap-2">
                        <Download className="w-4 h-4 text-muted-foreground" />
                        <p className="text-xs text-muted-foreground">File attached</p>
                      </div>
                    )}
                    <p className="text-xs text-muted-foreground">
                      Users can download this file after purchase
                    </p>
                  </div>
                  <Button onClick={handleSubmit} disabled={uploading} className="w-full">
                    {uploading ? 'Uploading...' : editingProduct ? 'Update Product' : 'Create Product'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Image</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>File</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products.map((product) => (
                  <TableRow key={product.id}>
                    <TableCell>
                      {product.image_url ? (
                        <img 
                          src={product.image_url} 
                          alt={product.name}
                          className="w-12 h-12 object-cover rounded"
                        />
                      ) : (
                        <div className="w-12 h-12 bg-muted rounded flex items-center justify-center text-xs text-muted-foreground">
                          No image
                        </div>
                      )}
                    </TableCell>
                    <TableCell className="font-medium">{product.name}</TableCell>
                    <TableCell>{product.price === 0 ? 'FREE' : `₹${product.price}`}</TableCell>
                    <TableCell>{product.category.replace('_', ' ')}</TableCell>
                    <TableCell>
                      {product.file_url ? (
                        <Download className="w-4 h-4 text-green-500" />
                      ) : (
                        <span className="text-xs text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell>{product.is_active ? 'Active' : 'Inactive'}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleOpenDialog(product)}
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDelete(product.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
