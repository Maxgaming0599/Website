import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { getCoupons, createCoupon, deleteCoupon } from '@/db/api';
import type { Coupon } from '@/types';
import { toast } from 'sonner';
import { Plus, Trash2, Ticket } from 'lucide-react';

export default function CouponsManagement() {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  
  const [code, setCode] = useState('');
  const [coinsReward, setCoinsReward] = useState('');
  const [expiryValue, setExpiryValue] = useState('');
  const [expiryUnit, setExpiryUnit] = useState<'m' | 'h' | 'd' | 'w' | 'mo' | 'y'>('d');

  useEffect(() => {
    loadCoupons();
  }, []);

  const loadCoupons = async () => {
    setLoading(true);
    const data = await getCoupons();
    setCoupons(data);
    setLoading(false);
  };

  const resetForm = () => {
    setCode('');
    setCoinsReward('');
    setExpiryValue('');
    setExpiryUnit('d');
  };

  const calculateExpiryDate = () => {
    const value = parseInt(expiryValue);
    if (isNaN(value) || value <= 0) return null;

    const now = new Date();
    switch (expiryUnit) {
      case 'm':
        now.setMinutes(now.getMinutes() + value);
        break;
      case 'h':
        now.setHours(now.getHours() + value);
        break;
      case 'd':
        now.setDate(now.getDate() + value);
        break;
      case 'w':
        now.setDate(now.getDate() + value * 7);
        break;
      case 'mo':
        now.setMonth(now.getMonth() + value);
        break;
      case 'y':
        now.setFullYear(now.getFullYear() + value);
        break;
    }
    return now.toISOString();
  };

  const handleSubmit = async () => {
    if (!code || !coinsReward || !expiryValue) {
      toast.error('Please fill in all fields');
      return;
    }

    const reward = parseInt(coinsReward);
    if (isNaN(reward) || reward <= 0) {
      toast.error('Please enter a valid reward amount');
      return;
    }

    const expiryDate = calculateExpiryDate();
    if (!expiryDate) {
      toast.error('Please enter a valid expiry time');
      return;
    }

    const result = await createCoupon({
      code: code.toUpperCase(),
      coins_reward: reward,
      expiry_date: expiryDate,
      is_active: true
    });

    if (result) {
      toast.success('Coupon created successfully');
      loadCoupons();
      setDialogOpen(false);
      resetForm();
    } else {
      toast.error('Failed to create coupon');
    }
  };

  const handleDelete = async (couponId: string) => {
    if (!confirm('Are you sure you want to delete this coupon?')) return;

    const success = await deleteCoupon(couponId);
    if (success) {
      toast.success('Coupon deleted successfully');
      loadCoupons();
    } else {
      toast.error('Failed to delete coupon');
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Coupons Management</CardTitle>
              <CardDescription>Create and manage coupon codes</CardDescription>
            </div>
            <Dialog open={dialogOpen} onOpenChange={(open) => {
              setDialogOpen(open);
              if (!open) resetForm();
            }}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus className="w-4 h-4" />
                  Add Coupon
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Coupon</DialogTitle>
                  <DialogDescription>
                    Set up a new coupon code with expiry time
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Coupon Code *</Label>
                    <Input
                      placeholder="WELCOME2024"
                      value={code}
                      onChange={(e) => setCode(e.target.value.toUpperCase())}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Coins Reward *</Label>
                    <Input
                      type="number"
                      placeholder="100"
                      value={coinsReward}
                      onChange={(e) => setCoinsReward(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Expiry Time *</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="7"
                        value={expiryValue}
                        onChange={(e) => setExpiryValue(e.target.value)}
                        className="flex-1"
                      />
                      <Select value={expiryUnit} onValueChange={(value) => setExpiryUnit(value as any)}>
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="m">Minutes</SelectItem>
                          <SelectItem value="h">Hours</SelectItem>
                          <SelectItem value="d">Days</SelectItem>
                          <SelectItem value="w">Weeks</SelectItem>
                          <SelectItem value="mo">Months</SelectItem>
                          <SelectItem value="y">Years</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <Button onClick={handleSubmit} className="w-full">
                    Create Coupon
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Code</TableHead>
                  <TableHead>Reward</TableHead>
                  <TableHead>Expiry Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {coupons.map((coupon) => (
                  <TableRow key={coupon.id}>
                    <TableCell className="font-mono font-bold">{coupon.code}</TableCell>
                    <TableCell>{coupon.coins_reward} coins</TableCell>
                    <TableCell>{new Date(coupon.expiry_date).toLocaleString()}</TableCell>
                    <TableCell>
                      {coupon.is_active && new Date(coupon.expiry_date) > new Date() ? (
                        <span className="text-green-600">Active</span>
                      ) : (
                        <span className="text-muted-foreground">Expired</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleDelete(coupon.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
