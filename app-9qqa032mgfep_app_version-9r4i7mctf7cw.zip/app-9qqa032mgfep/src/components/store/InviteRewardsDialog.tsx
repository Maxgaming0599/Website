import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Coins } from 'lucide-react';
import type { InviteReward } from '@/types';

interface InviteRewardsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const inviteRewards: InviteReward[] = [
  { coins: 500, invites: 5, members: '200K' },
  { coins: 1000, invites: 8, members: '500K' },
  { coins: 15000, invites: 12, members: '700K' },
  { coins: 2000, invites: 15, members: '800K' },
  { coins: 30000, invites: 20, members: '1M' },
  { coins: 80000, invites: 25, members: '1.5M' },
];

export default function InviteRewardsDialog({ open, onOpenChange }: InviteRewardsDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl">
            <Coins className="w-6 h-6 text-primary" />
            Invite Rewards
          </DialogTitle>
          <DialogDescription>
            Invite members to Discord and earn coins
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-3">
          {inviteRewards.map((reward, index) => (
            <div 
              key={index}
              className="flex items-center justify-between p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Coins className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <div className="font-bold text-lg">{reward.coins} Coins</div>
                  <div className="text-sm text-muted-foreground">
                    Invite {reward.invites} members
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-bold text-primary">{reward.members}</div>
                <div className="text-xs text-muted-foreground">Server Size</div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-sm text-muted-foreground text-center mt-4">
          Join our Discord server and start inviting to earn rewards!
        </div>
      </DialogContent>
    </Dialog>
  );
}
