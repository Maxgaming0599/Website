import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Ticket } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { redeemCoupon } from '@/db/api';
import { toast } from 'sonner';

interface CouponDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function CouponDialog({ open, onOpenChange }: CouponDialogProps) {
  const { user, refreshProfile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [couponCode, setCouponCode] = useState('');

  const handleRedeem = async () => {
    if (!user) {
      toast.error('Please login to redeem coupons');
      return;
    }

    if (!couponCode.trim()) {
      toast.error('Please enter a coupon code');
      return;
    }

    setLoading(true);
    try {
      const result = await redeemCoupon(user.id, couponCode.trim());
      
      if (result.success) {
        toast.success(`Redeemed! You received ${result.reward} coins!`);
        await refreshProfile();
        setCouponCode('');
        onOpenChange(false);
      } else {
        toast.error(result.message || 'Failed to redeem coupon');
      }
    } catch (error) {
      toast.error('Failed to redeem coupon');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(open) => {
      onOpenChange(open);
      if (!open) setCouponCode('');
    }}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl">
            <Ticket className="w-6 h-6 text-primary" />
            Redeem Coupon
          </DialogTitle>
          <DialogDescription>
            Enter your coupon code to claim rewards
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <Input
            placeholder="Enter coupon code"
            value={couponCode}
            onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
            disabled={loading}
          />

          <Button onClick={handleRedeem} disabled={loading || !user || !couponCode.trim()} className="w-full">
            {loading ? 'Redeeming...' : 'Redeem Coupon'}
          </Button>

          <div className="text-sm text-muted-foreground text-center">
            Coupons can only be used once per account
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
