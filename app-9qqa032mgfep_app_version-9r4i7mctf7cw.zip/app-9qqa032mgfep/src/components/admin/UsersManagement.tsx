import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { getAllProfiles, addCoins, removeCoins, updateUserRank, updateUserRole } from '@/db/api';
import type { Profile, RankType } from '@/types';
import { toast } from 'sonner';
import { Coins, Crown, Shield } from 'lucide-react';

export default function UsersManagement() {
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedUser, setSelectedUser] = useState<string>('');
  const [coinAmount, setCoinAmount] = useState('');
  const [selectedRank, setSelectedRank] = useState<RankType>('none');
  const [selectedRole, setSelectedRole] = useState<'user' | 'admin'>('user');
  const [ownerId, setOwnerId] = useState<string>('');

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    setLoading(true);
    const data = await getAllProfiles();
    setUsers(data);
    
    // Find the owner (first created user)
    if (data.length > 0) {
      const sortedByDate = [...data].sort((a, b) => 
        new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
      );
      setOwnerId(sortedByDate[0].id);
    }
    
    setLoading(false);
  };

  const isOwner = (userId: string) => userId === ownerId;

  const getSelectedUser = () => users.find(u => u.id === selectedUser);

  const handleAddCoins = async () => {
    if (!selectedUser || !coinAmount) {
      toast.error('Please select a user and enter amount');
      return;
    }

    const amount = parseInt(coinAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    const success = await addCoins(selectedUser, amount);
    if (success) {
      toast.success('Coins added successfully');
      loadUsers();
      setCoinAmount('');
    } else {
      toast.error('Failed to add coins');
    }
  };

  const handleRemoveCoins = async () => {
    if (!selectedUser || !coinAmount) {
      toast.error('Please select a user and enter amount');
      return;
    }

    const amount = parseInt(coinAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    const success = await removeCoins(selectedUser, amount);
    if (success) {
      toast.success('Coins removed successfully');
      loadUsers();
      setCoinAmount('');
    } else {
      toast.error('Failed to remove coins');
    }
  };

  const handleUpdateRank = async () => {
    if (!selectedUser) {
      toast.error('Please select a user');
      return;
    }

    const success = await updateUserRank(selectedUser, selectedRank);
    if (success) {
      toast.success('Rank updated successfully');
      loadUsers();
    } else {
      toast.error('Failed to update rank');
    }
  };

  const handleUpdateRole = async () => {
    if (!selectedUser) {
      toast.error('Please select a user');
      return;
    }

    if (isOwner(selectedUser)) {
      toast.error('Cannot change the owner\'s role');
      return;
    }

    const success = await updateUserRole(selectedUser, selectedRole);
    if (success) {
      toast.success('Role updated successfully');
      loadUsers();
    } else {
      toast.error('Failed to update role');
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>User Management</CardTitle>
          <CardDescription>Manage user coins, ranks, and roles</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* User Selection */}
          <div className="space-y-2">
            <Label>Select User</Label>
            <Select value={selectedUser} onValueChange={setSelectedUser}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a user" />
              </SelectTrigger>
              <SelectContent>
                {users.map((user) => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.username} ({user.coins} coins)
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Coin Management */}
          <div className="space-y-2">
            <Label>Coin Amount</Label>
            <Input
              type="number"
              placeholder="Enter amount"
              value={coinAmount}
              onChange={(e) => setCoinAmount(e.target.value)}
            />
            <div className="flex gap-2">
              <Button onClick={handleAddCoins} className="flex-1 gap-2">
                <Coins className="w-4 h-4" />
                Add Coins
              </Button>
              <Button onClick={handleRemoveCoins} variant="destructive" className="flex-1 gap-2">
                <Coins className="w-4 h-4" />
                Remove Coins
              </Button>
            </div>
          </div>

          {/* Rank Management */}
          <div className="space-y-2">
            <Label>Rank</Label>
            <Select value={selectedRank} onValueChange={(value) => setSelectedRank(value as RankType)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                <SelectItem value="vip">VIP</SelectItem>
                <SelectItem value="vip_plus">VIP+</SelectItem>
                <SelectItem value="premium">Premium</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={handleUpdateRank} className="w-full gap-2">
              <Crown className="w-4 h-4" />
              Update Rank
            </Button>
          </div>

          {/* Role Management */}
          <div className="space-y-2">
            <Label>Role</Label>
            <Select 
              value={selectedRole} 
              onValueChange={(value) => setSelectedRole(value as 'user' | 'admin')}
              disabled={!!(selectedUser && isOwner(selectedUser))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="user">User</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
              </SelectContent>
            </Select>
            {selectedUser && isOwner(selectedUser) && (
              <p className="text-xs text-muted-foreground">Owner's role cannot be changed</p>
            )}
            <Button 
              onClick={handleUpdateRole} 
              className="w-full gap-2"
              disabled={!!(selectedUser && isOwner(selectedUser))}
            >
              <Shield className="w-4 h-4" />
              Update Role
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Users</CardTitle>
          <CardDescription>Total: {users.length} users</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Username</TableHead>
                  <TableHead>Coins</TableHead>
                  <TableHead>Invites</TableHead>
                  <TableHead>Rank</TableHead>
                  <TableHead>Role</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">
                      {user.username}
                      {isOwner(user.id) && (
                        <Badge variant="destructive" className="ml-2">Owner</Badge>
                      )}
                    </TableCell>
                    <TableCell>{user.coins}</TableCell>
                    <TableCell>{user.invite_count}</TableCell>
                    <TableCell>
                      <Badge variant={user.rank === 'none' ? 'outline' : 'default'}>
                        {user.rank.replace('_', ' ').toUpperCase()}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={user.role === 'admin' ? 'destructive' : 'secondary'}>
                        {user.role.toUpperCase()}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
