-- Function to add coins to user
CREATE OR REPLACE FUNCTION public.add_coins(p_user_id uuid, p_amount integer)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.profiles
  SET coins = coins + p_amount,
      updated_at = now()
  WHERE id = p_user_id;
  
  INSERT INTO public.transactions (user_id, type, amount, description)
  VALUES (p_user_id, 'credit', p_amount, 'Coins added');
END;
$$;

-- Function to remove coins from user
CREATE OR REPLACE FUNCTION public.remove_coins(p_user_id uuid, p_amount integer)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.profiles
  SET coins = GREATEST(coins - p_amount, 0),
      updated_at = now()
  WHERE id = p_user_id;
  
  INSERT INTO public.transactions (user_id, type, amount, description)
  VALUES (p_user_id, 'debit', p_amount, 'Coins removed');
END;
$$;

-- Function to claim daily reward
CREATE OR REPLACE FUNCTION public.claim_daily_reward(p_user_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_profile record;
  v_reward_amount integer;
  v_cooldown_hours integer := 2;
BEGIN
  SELECT * INTO v_profile FROM public.profiles WHERE id = p_user_id;
  
  IF v_profile IS NULL THEN
    RETURN jsonb_build_object('success', false, 'message', 'User not found');
  END IF;
  
  IF v_profile.last_daily_claim IS NOT NULL AND 
     v_profile.last_daily_claim + (v_cooldown_hours || ' hours')::interval > now() THEN
    RETURN jsonb_build_object(
      'success', false, 
      'message', 'Cooldown active',
      'next_claim', v_profile.last_daily_claim + (v_cooldown_hours || ' hours')::interval
    );
  END IF;
  
  -- Calculate reward based on rank
  v_reward_amount := CASE v_profile.rank
    WHEN 'vip'::public.rank_type THEN 200
    WHEN 'vip_plus'::public.rank_type THEN 299
    WHEN 'premium'::public.rank_type THEN 300
    ELSE 100
  END;
  
  UPDATE public.profiles
  SET coins = coins + v_reward_amount,
      last_daily_claim = now(),
      updated_at = now()
  WHERE id = p_user_id;
  
  INSERT INTO public.transactions (user_id, type, amount, description)
  VALUES (p_user_id, 'daily_reward', v_reward_amount, 'Daily reward claimed');
  
  RETURN jsonb_build_object(
    'success', true, 
    'reward', v_reward_amount,
    'next_claim', now() + (v_cooldown_hours || ' hours')::interval
  );
END;
$$;

-- Function to claim AFK reward
CREATE OR REPLACE FUNCTION public.claim_afk_reward(p_user_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_profile record;
  v_reward_amount integer;
BEGIN
  SELECT * INTO v_profile FROM public.profiles WHERE id = p_user_id;
  
  IF v_profile IS NULL THEN
    RETURN jsonb_build_object('success', false, 'message', 'User not found');
  END IF;
  
  -- Calculate reward based on rank
  v_reward_amount := CASE v_profile.rank
    WHEN 'vip'::public.rank_type THEN 100
    WHEN 'vip_plus'::public.rank_type THEN 250
    WHEN 'premium'::public.rank_type THEN 299
    ELSE 50
  END;
  
  UPDATE public.profiles
  SET coins = coins + v_reward_amount,
      updated_at = now()
  WHERE id = p_user_id;
  
  INSERT INTO public.transactions (user_id, type, amount, description)
  VALUES (p_user_id, 'afk_reward', v_reward_amount, 'AFK video reward');
  
  RETURN jsonb_build_object('success', true, 'reward', v_reward_amount);
END;
$$;

-- Function to redeem coupon
CREATE OR REPLACE FUNCTION public.redeem_coupon(p_user_id uuid, p_coupon_code text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_coupon record;
  v_already_used boolean;
BEGIN
  SELECT * INTO v_coupon FROM public.coupons 
  WHERE code = p_coupon_code AND is_active = true AND expiry_date > now();
  
  IF v_coupon IS NULL THEN
    RETURN jsonb_build_object('success', false, 'message', 'Invalid or expired coupon');
  END IF;
  
  SELECT EXISTS(
    SELECT 1 FROM public.coupon_usage 
    WHERE user_id = p_user_id AND coupon_id = v_coupon.id
  ) INTO v_already_used;
  
  IF v_already_used THEN
    RETURN jsonb_build_object('success', false, 'message', 'Coupon already used');
  END IF;
  
  UPDATE public.profiles
  SET coins = coins + v_coupon.coins_reward,
      updated_at = now()
  WHERE id = p_user_id;
  
  INSERT INTO public.coupon_usage (user_id, coupon_id)
  VALUES (p_user_id, v_coupon.id);
  
  INSERT INTO public.transactions (user_id, type, amount, description)
  VALUES (p_user_id, 'coupon', v_coupon.coins_reward, 'Coupon redeemed: ' || p_coupon_code);
  
  RETURN jsonb_build_object('success', true, 'reward', v_coupon.coins_reward);
END;
$$;