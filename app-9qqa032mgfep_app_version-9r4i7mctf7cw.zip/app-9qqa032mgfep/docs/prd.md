# MineMart Requirements Document

## 1. Application Overview

### 1.1 Application Name
MineMart

### 1.2 Application Description
A Minecraft & Discord store website featuring a coin-based economy system, rank purchases, invite rewards, flashy sales system, and comprehensive admin management capabilities. The platform operates without a traditional login system.

## 2. Design Requirements

### 2.1 Visual Theme
- Background: Blue and Dark Blue gradient
- Loading animation: Animated blue text displaying "MineMart" with smooth intro animation
- After animation completes, automatically transition to main page

### 2.2 Admin Customization
Admins can modify:
- Website name
- Background colors
- Product prices

## 3. Main Page Features

### 3.1 Top Bar
- Animated title: "MineMart"
- Coins display at top-right corner
- Invite count display next to coins

### 3.2 Top Player Display
- Live display of top player with most coins
- Visible to all users

## 4. Coins System

### 4.1 Invite Rewards
When user clicks Coins, display coin emoji with reward tiers:
- 500 Coins → Invite 5 members in Discord (200K beside it)
- 1000 Coins → Invite 8 members (500K beside it)
- 15000 Coins → Invite 12 members (700K beside it)
- 2000 Coins → Invite 15 members (800K beside it)
- 30000 Coins → Invite 20 members (1M beside it)
- 80000 Coins → Invite 25 members (1.5M beside it)

### 4.2 Daily Coin System
- Daily Reward: 100 Coins
- Cooldown timer: 2 Hours

## 5. Store Features

### 5.1 Store Page Content
- Coin packages
- Rank purchases
- Offers

### 5.2 Admin Product Management
Admins can:
- Add product photo
- Add product images
- Add downloadable files (files will be available for download after payment)
- Add link to product (link will open when clicked)
- Add price (can be set to 0 for free products, or set to coins for coin-based purchases)
- Add description
- Create custom categories and subcategories
- Select category and subcategory for the product
- Click confirm to publish product publicly
- Products will automatically appear in their designated category and subcategory section

### 5.3 Product Purchase Options
- Products can be purchased with coins
- Products can be purchased with money (payment gateway)
- Ranks can be purchased with coins
- Ranks can be purchased with money (payment gateway)

### 5.4 Product Download/Link Behavior
- If product has uploaded file: File downloads automatically after purchase
- If product has link: Link opens when clicked after purchase

## 6. Ranks System

### 6.1 VIP Rank (₹70)
- Daily 200 Coins
- Discord VIP Role

### 6.2 VIP+ Rank (₹120)
- Daily 299 Coins
- Discord VIP+ Role

### 6.3 Premium Rank (₹180)
- Daily 300 Coins
- Discord Premium Role

## 7. Coupon System

### 7.1 User Interface
- Input field: "Enter Coupon"

### 7.2 Admin Coupon Management
Admin can:
- Create coupon
- Set expiry time using:
  - d = day
  - h = hour
  - m = minute
  - w = week
  - mo = month
  - y = year

## 8. Flashy Sale System

### 8.1 Owner Sale Management
Owner can:
- Change sale name to anything
- Choose number of products for sale
- Set discount percentage
- Activate/deactivate sale

## 9. Admin Panel

### 9.1 Access
- Admin Button (visible to admin only)
- When clicked: Show animated popup with "Admin Panel" text
- Cool opening animation
- Side navigation buttons

### 9.2 Admin Controls
- Give Coins
- Remove Coins
- Give Rank
- Remove Rank
- Add Coupon
- Set Coupon Expiry Time
- Add Products
- Create Categories
- Create Subcategories

### 9.3 Admin Dashboard View
Display:
- Total members
- Each member's coin balance
- Each member's rank
- Grant admin access to other users

### 9.4 Admin Extra Powers
- Change website name
- Change background theme
- Change product prices
- Modify ranks
- Add/remove admins
- Create and manage custom categories and subcategories

## 10. Owner Panel

### 10.1 Owner Exclusive Access
Only accessible to owner

### 10.2 Owner Role Management
Owner can:
- Create new roles
- Update existing roles
- Edit roles and ranks
- Set coin rewards for each role (daily coins)
- Manage role permissions

### 10.3 Owner Sale Management
- Create and manage flashy sales
- Change sale name
- Select products for sale
- Set discount percentage
- Activate/deactivate sales

### 10.4 Owner Analytics
Display:
- Total sales data
- Revenue statistics
- User engagement metrics
- Product performance

### 10.5 Owner Protection
- The first user to login becomes the owner
- Owner cannot be removed by anyone
- Owner can remove any admin or user
- Only owner has permanent admin status

## 11. Category System

### 11.1 Custom Category Management
- Admins can create custom categories
- Admins can create subcategories under each category
- Products can be assigned to specific category and subcategory combinations

### 11.2 Default Minecraft Section
Two options: Free and Premium

Both include categories:
- Map
- Plugins
- Setup
- Config
- Models
- Skript

### 11.3 Default Discord Section

**Free Option includes:**
- Template
- Bot

**Premium Option includes:**
- Template
- Bot
- Discord Setup

### 11.4 Product Display
- Products added by admin will automatically appear in their assigned category and subcategory
- Free products can have price set to 0
- Each product displays in its respective category and subcategory section
- Products with downloadable files will allow users to download after payment completion
- Products with links will open the link when clicked after payment completion

## 12. Payment Integration
Payment gateway: Any supported gateway (Razorpay, Stripe, PayPal, or others)

## 13. Data Storage
User data storage solution: Any preferred database or recommended solution for storing:
- Coins
- Ranks
- Invite counts
- Purchase history
- Downloadable files associated with products
- Product links
- Sale configurations
- Analytics data