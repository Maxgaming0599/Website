import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getProducts } from '@/db/api';
import type { Product, ProductCategory } from '@/types';
import ProductCard from '@/components/store/ProductCard';

export default function StorePage() {
  const { profile } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    setLoading(true);
    const data = await getProducts();
    setProducts(data);
    setLoading(false);
  };

  const filterByCategory = (category: ProductCategory) => {
    return products.filter(p => p.category === category);
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold mb-8 text-center gradient-text">
          Store
        </h1>

        <Tabs defaultValue="coins" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="coins">Coins</TabsTrigger>
            <TabsTrigger value="ranks">Ranks</TabsTrigger>
            <TabsTrigger value="offers">Offers</TabsTrigger>
          </TabsList>

          <TabsContent value="coins">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filterByCategory('coins').map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
              {filterByCategory('coins').length === 0 && (
                <p className="col-span-full text-center text-muted-foreground py-8">
                  No coin packages available
                </p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="ranks">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filterByCategory('ranks').map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
              {filterByCategory('ranks').length === 0 && (
                <p className="col-span-full text-center text-muted-foreground py-8">
                  No ranks available
                </p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="offers">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filterByCategory('offers').map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
              {filterByCategory('offers').length === 0 && (
                <p className="col-span-full text-center text-muted-foreground py-8">
                  No special offers available
                </p>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
