-- Function to get the owner (first user)
CREATE OR REPLACE FUNCTION public.get_owner_id()
RETURNS uuid
LANGUAGE sql
STABLE
AS $$
  SELECT id FROM public.profiles ORDER BY created_at ASC LIMIT 1;
$$;

-- Update the profiles update policy to protect owner's role
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (
    -- Users can update their own profile but cannot change their role
    -- unless they are admin changing someone else's role (handled by admin policy)
    role IS NOT DISTINCT FROM (SELECT role FROM public.profiles WHERE id = auth.uid())
  );

-- Update admin policy to prevent changing owner's role
DROP POLICY IF EXISTS "Admins have full access to profiles" ON public.profiles;

CREATE POLICY "Admins have full access to profiles"
  ON public.profiles FOR ALL
  USING (public.is_admin(auth.uid()))
  WITH CHECK (
    public.is_admin(auth.uid()) AND 
    -- Prevent changing the owner's role
    (id != public.get_owner_id() OR role = (SELECT role FROM public.profiles WHERE id = public.get_owner_id()))
  );