import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Gift, Clock } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { claimDailyReward } from '@/db/api';
import { toast } from 'sonner';

interface DailyRewardDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function DailyRewardDialog({ open, onOpenChange }: DailyRewardDialogProps) {
  const { user, profile, refreshProfile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [cooldown, setCooldown] = useState<string | null>(null);

  useEffect(() => {
    if (open && profile?.last_daily_claim) {
      const lastClaim = new Date(profile.last_daily_claim);
      const nextClaim = new Date(lastClaim.getTime() + 2 * 60 * 60 * 1000); // 2 hours
      const now = new Date();
      
      if (now < nextClaim) {
        const diff = nextClaim.getTime() - now.getTime();
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        setCooldown(`${hours}h ${minutes}m`);
      } else {
        setCooldown(null);
      }
    } else {
      setCooldown(null);
    }
  }, [open, profile]);

  const handleClaim = async () => {
    if (!user) {
      toast.error('Please login to claim rewards');
      return;
    }

    setLoading(true);
    try {
      const result = await claimDailyReward(user.id);
      
      if (result.success) {
        toast.success(`Claimed ${result.reward} coins!`);
        await refreshProfile();
        onOpenChange(false);
      } else {
        toast.error(result.message || 'Failed to claim reward');
      }
    } catch (error) {
      toast.error('Failed to claim reward');
    } finally {
      setLoading(false);
    }
  };

  const getRewardAmount = () => {
    switch (profile?.rank) {
      case 'vip': return 200;
      case 'vip_plus': return 299;
      case 'premium': return 300;
      default: return 100;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl">
            <Gift className="w-6 h-6 text-primary" />
            Daily Reward
          </DialogTitle>
          <DialogDescription>
            Claim your daily coins reward
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="text-center py-6">
            <div className="text-5xl font-bold gradient-text mb-2">
              {getRewardAmount()}
            </div>
            <p className="text-muted-foreground">Coins</p>
          </div>

          {cooldown ? (
            <div className="flex items-center justify-center gap-2 text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span>Next claim in: {cooldown}</span>
            </div>
          ) : (
            <Button onClick={handleClaim} disabled={loading || !user} className="w-full">
              {loading ? 'Claiming...' : 'Claim Reward'}
            </Button>
          )}

          <div className="text-sm text-muted-foreground text-center">
            Cooldown: 2 Hours
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
