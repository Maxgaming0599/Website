import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getProducts } from '@/db/api';
import type { Product, ProductCategory } from '@/types';
import ProductCard from '@/components/store/ProductCard';

export default function CategoriesPage() {
  const [searchParams] = useSearchParams();
  const type = searchParams.get('type') || 'minecraft';
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    const data = await getProducts();
    setProducts(data);
  };

  const filterByCategory = (category: ProductCategory) => {
    return products.filter(p => p.category === category);
  };

  const filterBySubcategory = (category: ProductCategory, subcategory: string) => {
    return products.filter(p => 
      p.category === category && 
      (p.name.toLowerCase().includes(subcategory.toLowerCase()) || 
       p.description?.toLowerCase().includes(subcategory.toLowerCase()))
    );
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold mb-8 text-center gradient-text">
          {type === 'minecraft' ? '🎮 Minecraft' : '💬 Discord'}
        </h1>

        {type === 'minecraft' ? (
          <Tabs defaultValue="free" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="free">Free</TabsTrigger>
              <TabsTrigger value="premium">Premium</TabsTrigger>
            </TabsList>

            <TabsContent value="free">
              <div className="space-y-8">
                <CategorySection title="Maps" products={filterBySubcategory('minecraft_free', 'map')} />
                <CategorySection title="Plugins" products={filterBySubcategory('minecraft_free', 'plugin')} />
                <CategorySection title="Setup" products={filterBySubcategory('minecraft_free', 'setup')} />
                <CategorySection title="Config" products={filterBySubcategory('minecraft_free', 'config')} />
                <CategorySection title="Models" products={filterBySubcategory('minecraft_free', 'model')} />
                <CategorySection title="Skript" products={filterBySubcategory('minecraft_free', 'skript')} />
                {filterByCategory('minecraft_free').length > 0 && (
                  <CategorySection title="All Free Items" products={filterByCategory('minecraft_free')} />
                )}
              </div>
            </TabsContent>

            <TabsContent value="premium">
              <div className="space-y-8">
                <CategorySection title="Maps" products={filterBySubcategory('minecraft_premium', 'map')} />
                <CategorySection title="Plugins" products={filterBySubcategory('minecraft_premium', 'plugin')} />
                <CategorySection title="Setup" products={filterBySubcategory('minecraft_premium', 'setup')} />
                <CategorySection title="Config" products={filterBySubcategory('minecraft_premium', 'config')} />
                <CategorySection title="Models" products={filterBySubcategory('minecraft_premium', 'model')} />
                <CategorySection title="Skript" products={filterBySubcategory('minecraft_premium', 'skript')} />
                {filterByCategory('minecraft_premium').length > 0 && (
                  <CategorySection title="All Premium Items" products={filterByCategory('minecraft_premium')} />
                )}
              </div>
            </TabsContent>
          </Tabs>
        ) : (
          <Tabs defaultValue="free" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="free">Free</TabsTrigger>
              <TabsTrigger value="premium">Premium</TabsTrigger>
            </TabsList>

            <TabsContent value="free">
              <div className="space-y-8">
                <CategorySection title="Templates" products={filterBySubcategory('discord_free', 'template')} />
                <CategorySection title="Bots" products={filterBySubcategory('discord_free', 'bot')} />
                {filterByCategory('discord_free').length > 0 && (
                  <CategorySection title="All Free Items" products={filterByCategory('discord_free')} />
                )}
              </div>
            </TabsContent>

            <TabsContent value="premium">
              <div className="space-y-8">
                <CategorySection title="Templates" products={filterBySubcategory('discord_premium', 'template')} />
                <CategorySection title="Bots" products={filterBySubcategory('discord_premium', 'bot')} />
                <CategorySection title="Discord Setup" products={filterBySubcategory('discord_premium', 'setup')} />
                {filterByCategory('discord_premium').length > 0 && (
                  <CategorySection title="All Premium Items" products={filterByCategory('discord_premium')} />
                )}
              </div>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
}

function CategorySection({ title, products }: { title: string; products: Product[] }) {
  if (products.length === 0) {
    return null;
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">{title}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}
