-- Create custom roles table
CREATE TABLE public.custom_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  permissions jsonb DEFAULT '[]'::jsonb,
  is_active boolean DEFAULT true NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Create custom ranks table with coin rewards
CREATE TABLE public.custom_ranks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  slug text UNIQUE NOT NULL,
  price_inr numeric NOT NULL DEFAULT 0,
  price_coins numeric NOT NULL DEFAULT 0,
  daily_coins integer NOT NULL DEFAULT 100,
  description text,
  is_active boolean DEFAULT true NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Create flash sales table
CREATE TABLE public.flash_sales (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  discount_percentage integer NOT NULL CHECK (discount_percentage >= 0 AND discount_percentage <= 100),
  product_ids uuid[] NOT NULL DEFAULT '{}',
  is_active boolean DEFAULT false NOT NULL,
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Add new columns to products
ALTER TABLE public.products 
  ADD COLUMN IF NOT EXISTS coins_price integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS external_link text;

-- Add top_players_visible to site_settings
ALTER TABLE public.site_settings
  ADD COLUMN IF NOT EXISTS top_players_visible boolean DEFAULT true;

-- Insert default custom ranks based on existing system
INSERT INTO public.custom_ranks (name, slug, price_inr, price_coins, daily_coins, description) VALUES
  ('VIP', 'vip', 70, 5000, 200, 'VIP rank with 200 daily coins'),
  ('VIP+', 'vip_plus', 120, 8000, 299, 'VIP+ rank with 299 daily coins'),
  ('Premium', 'premium', 180, 12000, 300, 'Premium rank with 300 daily coins');

-- Create indexes
CREATE INDEX idx_custom_roles_name ON public.custom_roles(name);
CREATE INDEX idx_custom_ranks_slug ON public.custom_ranks(slug);
CREATE INDEX idx_flash_sales_active ON public.flash_sales(is_active);
CREATE INDEX idx_products_coins_price ON public.products(coins_price);

-- Enable RLS
ALTER TABLE public.custom_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.custom_ranks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.flash_sales ENABLE ROW LEVEL SECURITY;

-- Custom roles policies
CREATE POLICY "Anyone can view active roles"
  ON public.custom_roles FOR SELECT
  USING (is_active = true);

CREATE POLICY "Owner can manage roles"
  ON public.custom_roles FOR ALL
  USING (auth.uid() = public.get_owner_id());

-- Custom ranks policies
CREATE POLICY "Anyone can view active ranks"
  ON public.custom_ranks FOR SELECT
  USING (is_active = true);

CREATE POLICY "Owner can manage ranks"
  ON public.custom_ranks FOR ALL
  USING (auth.uid() = public.get_owner_id());

-- Flash sales policies
CREATE POLICY "Anyone can view active flash sales"
  ON public.flash_sales FOR SELECT
  USING (is_active = true);

CREATE POLICY "Admins can manage flash sales"
  ON public.flash_sales FOR ALL
  USING (public.is_admin(auth.uid()));

-- Drop and recreate claim_daily_reward function
DROP FUNCTION IF EXISTS public.claim_daily_reward(uuid);

CREATE FUNCTION public.claim_daily_reward(p_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_last_claim timestamptz;
  v_rank text;
  v_reward_amount integer;
BEGIN
  -- Get user's last claim and rank
  SELECT last_daily_claim, rank INTO v_last_claim, v_rank
  FROM public.profiles
  WHERE id = p_user_id;

  -- Check cooldown (2 hours)
  IF v_last_claim IS NOT NULL AND v_last_claim + INTERVAL '2 hours' > now() THEN
    RETURN false;
  END IF;

  -- Get reward amount based on rank from custom_ranks table
  SELECT daily_coins INTO v_reward_amount
  FROM public.custom_ranks
  WHERE slug = v_rank AND is_active = true;

  -- Default to 100 if rank not found
  IF v_reward_amount IS NULL THEN
    v_reward_amount := 100;
  END IF;

  -- Update coins and last claim time
  UPDATE public.profiles
  SET 
    coins = coins + v_reward_amount,
    last_daily_claim = now()
  WHERE id = p_user_id;

  -- Log transaction
  INSERT INTO public.transactions (user_id, type, amount, description)
  VALUES (p_user_id, 'daily_reward', v_reward_amount, 'Daily reward claimed');

  RETURN true;
END;
$$;

-- Function to buy product with coins
CREATE OR REPLACE FUNCTION public.buy_with_coins(
  p_user_id uuid,
  p_product_id uuid
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_coins_price integer;
  v_user_coins integer;
BEGIN
  -- Get product price and user coins
  SELECT coins_price INTO v_coins_price
  FROM public.products
  WHERE id = p_product_id AND is_active = true;

  SELECT coins INTO v_user_coins
  FROM public.profiles
  WHERE id = p_user_id;

  -- Check if product exists and has coins price
  IF v_coins_price IS NULL OR v_coins_price = 0 THEN
    RETURN false;
  END IF;

  -- Check if user has enough coins
  IF v_user_coins < v_coins_price THEN
    RETURN false;
  END IF;

  -- Deduct coins
  UPDATE public.profiles
  SET coins = coins - v_coins_price
  WHERE id = p_user_id;

  -- Create purchase record
  INSERT INTO public.purchases (user_id, product_id)
  VALUES (p_user_id, p_product_id);

  -- Log transaction
  INSERT INTO public.transactions (user_id, type, amount, description)
  VALUES (p_user_id, 'purchase', -v_coins_price, 'Purchased product with coins');

  RETURN true;
END;
$$;

-- Function to buy rank with coins
CREATE OR REPLACE FUNCTION public.buy_rank_with_coins(
  p_user_id uuid,
  p_rank_slug text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_coins_price numeric;
  v_user_coins integer;
BEGIN
  -- Get rank price and user coins
  SELECT price_coins INTO v_coins_price
  FROM public.custom_ranks
  WHERE slug = p_rank_slug AND is_active = true;

  SELECT coins INTO v_user_coins
  FROM public.profiles
  WHERE id = p_user_id;

  -- Check if rank exists and has coins price
  IF v_coins_price IS NULL OR v_coins_price = 0 THEN
    RETURN false;
  END IF;

  -- Check if user has enough coins
  IF v_user_coins < v_coins_price THEN
    RETURN false;
  END IF;

  -- Deduct coins and update rank
  UPDATE public.profiles
  SET 
    coins = coins - v_coins_price::integer,
    rank = p_rank_slug::public.rank_type
  WHERE id = p_user_id;

  -- Log transaction
  INSERT INTO public.transactions (user_id, type, amount, description)
  VALUES (p_user_id, 'rank_purchase', -v_coins_price::integer, 'Purchased rank with coins: ' || p_rank_slug);

  RETURN true;
END;
$$;