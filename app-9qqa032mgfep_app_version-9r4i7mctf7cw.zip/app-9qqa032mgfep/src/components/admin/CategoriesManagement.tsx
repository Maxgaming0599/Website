import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  getAllCategories, 
  createCategory, 
  updateCategory, 
  deleteCategory,
  getAllSubcategories,
  createSubcategory,
  updateSubcategory,
  deleteSubcategory
} from '@/db/api';
import type { Category, Subcategory } from '@/types';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, FolderTree } from 'lucide-react';

export default function CategoriesManagement() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Category dialog state
  const [categoryDialogOpen, setCategoryDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [categoryName, setCategoryName] = useState('');
  const [categorySlug, setCategorySlug] = useState('');
  const [categoryDescription, setCategoryDescription] = useState('');
  
  // Subcategory dialog state
  const [subcategoryDialogOpen, setSubcategoryDialogOpen] = useState(false);
  const [editingSubcategory, setEditingSubcategory] = useState<Subcategory | null>(null);
  const [subcategoryName, setSubcategoryName] = useState('');
  const [subcategorySlug, setSubcategorySlug] = useState('');
  const [subcategoryDescription, setSubcategoryDescription] = useState('');
  const [selectedCategoryId, setSelectedCategoryId] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [cats, subs] = await Promise.all([
      getAllCategories(),
      getAllSubcategories()
    ]);
    setCategories(cats);
    setSubcategories(subs);
    setLoading(false);
  };

  // Category functions
  const resetCategoryForm = () => {
    setCategoryName('');
    setCategorySlug('');
    setCategoryDescription('');
    setEditingCategory(null);
  };

  const handleOpenCategoryDialog = (category?: Category) => {
    if (category) {
      setEditingCategory(category);
      setCategoryName(category.name);
      setCategorySlug(category.slug);
      setCategoryDescription(category.description || '');
    } else {
      resetCategoryForm();
    }
    setCategoryDialogOpen(true);
  };

  const generateSlug = (name: string) => {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  };

  const handleCategoryNameChange = (name: string) => {
    setCategoryName(name);
    if (!editingCategory) {
      setCategorySlug(generateSlug(name));
    }
  };

  const handleSubmitCategory = async () => {
    if (!categoryName || !categorySlug) {
      toast.error('Please fill in all required fields');
      return;
    }

    const categoryData = {
      name: categoryName,
      slug: categorySlug,
      description: categoryDescription || undefined
    };

    let success = false;
    if (editingCategory) {
      success = await updateCategory(editingCategory.id, categoryData);
      if (success) toast.success('Category updated successfully');
    } else {
      const result = await createCategory(categoryData);
      success = !!result;
      if (success) toast.success('Category created successfully');
    }

    if (success) {
      loadData();
      setCategoryDialogOpen(false);
      resetCategoryForm();
    } else {
      toast.error('Failed to save category');
    }
  };

  const handleDeleteCategory = async (categoryId: string) => {
    if (!confirm('Are you sure you want to delete this category? All subcategories will also be deleted.')) return;

    const success = await deleteCategory(categoryId);
    if (success) {
      toast.success('Category deleted successfully');
      loadData();
    } else {
      toast.error('Failed to delete category');
    }
  };

  // Subcategory functions
  const resetSubcategoryForm = () => {
    setSubcategoryName('');
    setSubcategorySlug('');
    setSubcategoryDescription('');
    setSelectedCategoryId('');
    setEditingSubcategory(null);
  };

  const handleOpenSubcategoryDialog = (subcategory?: Subcategory) => {
    if (subcategory) {
      setEditingSubcategory(subcategory);
      setSubcategoryName(subcategory.name);
      setSubcategorySlug(subcategory.slug);
      setSubcategoryDescription(subcategory.description || '');
      setSelectedCategoryId(subcategory.category_id);
    } else {
      resetSubcategoryForm();
    }
    setSubcategoryDialogOpen(true);
  };

  const handleSubcategoryNameChange = (name: string) => {
    setSubcategoryName(name);
    if (!editingSubcategory) {
      setSubcategorySlug(generateSlug(name));
    }
  };

  const handleSubmitSubcategory = async () => {
    if (!subcategoryName || !subcategorySlug || !selectedCategoryId) {
      toast.error('Please fill in all required fields');
      return;
    }

    const subcategoryData = {
      category_id: selectedCategoryId,
      name: subcategoryName,
      slug: subcategorySlug,
      description: subcategoryDescription || undefined
    };

    let success = false;
    if (editingSubcategory) {
      success = await updateSubcategory(editingSubcategory.id, subcategoryData);
      if (success) toast.success('Subcategory updated successfully');
    } else {
      const result = await createSubcategory(subcategoryData);
      success = !!result;
      if (success) toast.success('Subcategory created successfully');
    }

    if (success) {
      loadData();
      setSubcategoryDialogOpen(false);
      resetSubcategoryForm();
    } else {
      toast.error('Failed to save subcategory');
    }
  };

  const handleDeleteSubcategory = async (subcategoryId: string) => {
    if (!confirm('Are you sure you want to delete this subcategory?')) return;

    const success = await deleteSubcategory(subcategoryId);
    if (success) {
      toast.success('Subcategory deleted successfully');
      loadData();
    } else {
      toast.error('Failed to delete subcategory');
    }
  };

  const getCategoryName = (categoryId: string) => {
    return categories.find(c => c.id === categoryId)?.name || 'Unknown';
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="categories" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="subcategories">Subcategories</TabsTrigger>
        </TabsList>

        {/* Categories Tab */}
        <TabsContent value="categories">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Categories Management</CardTitle>
                  <CardDescription>Create and manage product categories</CardDescription>
                </div>
                <Dialog open={categoryDialogOpen} onOpenChange={(open) => {
                  setCategoryDialogOpen(open);
                  if (!open) resetCategoryForm();
                }}>
                  <DialogTrigger asChild>
                    <Button onClick={() => handleOpenCategoryDialog()} className="gap-2">
                      <Plus className="w-4 h-4" />
                      Add Category
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>{editingCategory ? 'Edit Category' : 'Add New Category'}</DialogTitle>
                      <DialogDescription>
                        {editingCategory ? 'Update category details' : 'Create a new category for products'}
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label>Name *</Label>
                        <Input
                          placeholder="Category name"
                          value={categoryName}
                          onChange={(e) => handleCategoryNameChange(e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Slug *</Label>
                        <Input
                          placeholder="category-slug"
                          value={categorySlug}
                          onChange={(e) => setCategorySlug(e.target.value)}
                        />
                        <p className="text-xs text-muted-foreground">URL-friendly identifier</p>
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea
                          placeholder="Category description"
                          value={categoryDescription}
                          onChange={(e) => setCategoryDescription(e.target.value)}
                        />
                      </div>
                      <Button onClick={handleSubmitCategory} className="w-full">
                        {editingCategory ? 'Update Category' : 'Create Category'}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Slug</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {categories.map((category) => (
                    <TableRow key={category.id}>
                      <TableCell className="font-medium">{category.name}</TableCell>
                      <TableCell>{category.slug}</TableCell>
                      <TableCell>{category.description || '-'}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleOpenCategoryDialog(category)}
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleDeleteCategory(category.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Subcategories Tab */}
        <TabsContent value="subcategories">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Subcategories Management</CardTitle>
                  <CardDescription>Create and manage product subcategories</CardDescription>
                </div>
                <Dialog open={subcategoryDialogOpen} onOpenChange={(open) => {
                  setSubcategoryDialogOpen(open);
                  if (!open) resetSubcategoryForm();
                }}>
                  <DialogTrigger asChild>
                    <Button onClick={() => handleOpenSubcategoryDialog()} className="gap-2">
                      <Plus className="w-4 h-4" />
                      Add Subcategory
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>{editingSubcategory ? 'Edit Subcategory' : 'Add New Subcategory'}</DialogTitle>
                      <DialogDescription>
                        {editingSubcategory ? 'Update subcategory details' : 'Create a new subcategory'}
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label>Parent Category *</Label>
                        <Select value={selectedCategoryId} onValueChange={setSelectedCategoryId}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map((cat) => (
                              <SelectItem key={cat.id} value={cat.id}>
                                {cat.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Name *</Label>
                        <Input
                          placeholder="Subcategory name"
                          value={subcategoryName}
                          onChange={(e) => handleSubcategoryNameChange(e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Slug *</Label>
                        <Input
                          placeholder="subcategory-slug"
                          value={subcategorySlug}
                          onChange={(e) => setSubcategorySlug(e.target.value)}
                        />
                        <p className="text-xs text-muted-foreground">URL-friendly identifier</p>
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea
                          placeholder="Subcategory description"
                          value={subcategoryDescription}
                          onChange={(e) => setSubcategoryDescription(e.target.value)}
                        />
                      </div>
                      <Button onClick={handleSubmitSubcategory} className="w-full">
                        {editingSubcategory ? 'Update Subcategory' : 'Create Subcategory'}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Category</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Slug</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {subcategories.map((subcategory) => (
                    <TableRow key={subcategory.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <FolderTree className="w-4 h-4 text-muted-foreground" />
                          {getCategoryName(subcategory.category_id)}
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{subcategory.name}</TableCell>
                      <TableCell>{subcategory.slug}</TableCell>
                      <TableCell>{subcategory.description || '-'}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleOpenSubcategoryDialog(subcategory)}
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleDeleteSubcategory(subcategory.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
