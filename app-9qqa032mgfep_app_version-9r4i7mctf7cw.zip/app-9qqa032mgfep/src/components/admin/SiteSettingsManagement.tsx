import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { getSiteSettings, updateSiteSettings } from '@/db/api';
import type { SiteSettings } from '@/types';
import { toast } from 'sonner';
import { Settings } from 'lucide-react';

export default function SiteSettingsManagement() {
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  const [siteName, setSiteName] = useState('');
  const [bgColor1, setBgColor1] = useState('');
  const [bgColor2, setBgColor2] = useState('');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    const data = await getSiteSettings();
    if (data) {
      setSettings(data);
      setSiteName(data.site_name);
      setBgColor1(data.bg_color_1);
      setBgColor2(data.bg_color_2);
    }
    setLoading(false);
  };

  const handleSave = async () => {
    if (!settings) return;

    if (!siteName.trim()) {
      toast.error('Please enter a site name');
      return;
    }

    setSaving(true);
    const success = await updateSiteSettings(settings.id, {
      site_name: siteName.trim(),
      bg_color_1: bgColor1,
      bg_color_2: bgColor2
    });

    if (success) {
      toast.success('Settings updated successfully');
      loadSettings();
    } else {
      toast.error('Failed to update settings');
    }
    setSaving(false);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Site Settings
          </CardTitle>
          <CardDescription>Customize your store appearance</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Site Name</Label>
            <Input
              placeholder="MineMart"
              value={siteName}
              onChange={(e) => setSiteName(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label>Background Color 1 (Hex)</Label>
            <div className="flex gap-2">
              <Input
                placeholder="#1e3a8a"
                value={bgColor1}
                onChange={(e) => setBgColor1(e.target.value)}
              />
              <input
                type="color"
                value={bgColor1}
                onChange={(e) => setBgColor1(e.target.value)}
                className="w-12 h-10 rounded border"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Background Color 2 (Hex)</Label>
            <div className="flex gap-2">
              <Input
                placeholder="#0f172a"
                value={bgColor2}
                onChange={(e) => setBgColor2(e.target.value)}
              />
              <input
                type="color"
                value={bgColor2}
                onChange={(e) => setBgColor2(e.target.value)}
                className="w-12 h-10 rounded border"
              />
            </div>
          </div>

          <div className="p-4 rounded-lg" style={{
            background: `linear-gradient(135deg, ${bgColor1}, ${bgColor2})`
          }}>
            <p className="text-white text-center font-bold">Preview</p>
          </div>

          <Button onClick={handleSave} disabled={saving} className="w-full">
            {saving ? 'Saving...' : 'Save Settings'}
          </Button>

          <div className="text-sm text-muted-foreground">
            Note: Background color changes will be reflected after page reload
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
